"""
The WEKA trace format and data arguments.

Reads a trace file and yields one row per line with a
synthetic prompt matching the requested input_length for replay
benchmarks. Checks for distinctness between hash IDs that share the
same previous hash ID.

Generates prompts starting from the first conversation.
When the conversation ends, the next conversation will be used.

Declared ``type: "subagent"`` groups are replayed as isolated child
chains that spawn from the preceding parent turn and join the following
parent turn. ``stop: tool_use`` and ``input_types: tool_result`` map
onto the existing client tool-call columns (``turn_type``, ``tools``,
``tool_response``).
"""

from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import Any

from datasets import Dataset, Features, List, Value
from faker import Faker
from transformers import PreTrainedTokenizerBase

from guidellm.data.deserializers.deserializer import (
    DataNotSupportedError,
    DatasetDeserializerFactory,
)
from guidellm.data.deserializers.trace_common import (
    TraceDatasetDeserializer,
    TraceFormatBase,
    TraceFormatRegistry,
    _validate_api_row,
    create_prompt_from_hash_ids,
    decode_prompt,
    duration_columns,
    fill_hash_id_table,
    generate_token_ids,
    get_missing_columns,
)
from guidellm.data.schemas import InvalidRowError
from guidellm.data.schemas.conversation_graph_data import (
    ConversationGraphData,
    ConversationParentRef,
    ConversationTurnData,
)
from guidellm.logger import logger
from guidellm.scheduler.schemas import HistoryContext
from guidellm.schemas import TurnType
from guidellm.schemas.data.deserializers import (
    DEFAULT_SYNTHETIC_TOOLS,
    WEKATraceFormatArgs,
)
from guidellm.settings import settings
from guidellm.utils.imports import json
from guidellm.utils.random import IntegerRangeSampler

__all__ = ["WEKATraceFormat"]


def _find_requests_column(dataset: Dataset) -> str | None:
    for name, val in dataset.features.items():
        if (
            isinstance(val, List)
            and len(dataset[name][0]) > 0
            and isinstance(dataset[name][0][0], dict)
        ):
            return name
    return None


def _generate_remaining_prompt(
    num_tokens: int, processor: PreTrainedTokenizerBase, faker: Faker
) -> str:
    if num_tokens == 0:
        return ""
    token_ids = generate_token_ids(num_tokens, processor, faker)
    return decode_prompt(processor, list(token_ids))


def _is_subagent_entry(row: dict[str, Any]) -> bool:
    return row.get("type") == "subagent"


def _first_api_request(requests: list[Any]) -> dict[str, Any] | None:
    for row in requests:
        if not isinstance(row, dict):
            continue
        if _is_subagent_entry(row):
            inner = row.get("requests")
            if not inner:
                continue
            found = _first_api_request(inner)
            if found is not None:
                return found
            continue
        return row
    return None


def _optional_float(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)


def _inner_timestamp_transform(
    entry: dict[str, Any],
    inner_requests: list[dict[str, Any]],
    timestamp_column: str,
) -> Callable[[float], float]:
    """Map inner ``t`` to conversation-absolute time.

    The spec records inner timestamps relative to spawn. Published corpora
    often store absolute ``t`` on the same timeline as the parent. If the
    first inner timestamp is less than the subagent spawn time, treat
    inners as relative (``spawn_t + inner_t``); otherwise leave them as-is.
    """
    spawn_t = float(entry[timestamp_column])
    first_inner_t = float(inner_requests[0][timestamp_column])
    if first_inner_t < spawn_t:

        def _relative(inner_t: float) -> float:
            return spawn_t + inner_t

        return _relative

    def _absolute(inner_t: float) -> float:
        return inner_t

    return _absolute


def _absolute_request_times(
    requests: list[Any],
    timestamp_column: str,
    t_transform: Callable[[float], float],
) -> list[float]:
    """Collect API request times on the conversation-absolute timeline.

    :param requests: API rows and nested subagent groups
    :param timestamp_column: Request timestamp field name
    :param t_transform: Maps this list's raw ``t`` onto conversation-absolute time
    :return: Absolute timestamps for API requests in ``requests``
    """
    times: list[float] = []
    for item in requests:
        if not isinstance(item, dict):
            continue
        if _is_subagent_entry(item):
            inner = [dict(row) for row in (item.get("requests") or [])]
            if not inner:
                continue
            transform = _inner_timestamp_transform(item, inner, timestamp_column)
            times.extend(_absolute_request_times(inner, timestamp_column, transform))
            continue
        raw = item.get(timestamp_column)
        if raw is None:
            continue
        times.append(t_transform(float(raw)))
    return times


def _copy_api_row(row: dict[str, Any], hash_ids_column: str) -> dict[str, Any]:
    copied = dict(row)
    hash_ids = copied.get(hash_ids_column)
    if hash_ids is not None:
        copied[hash_ids_column] = list(hash_ids)
    return copied


def _weka_stop_reason(row: dict[str, Any]) -> str:
    stop = row.get("stop")
    return stop if isinstance(stop, str) else ""


def _weka_input_types(row: dict[str, Any]) -> list[Any]:
    raw = row.get("input_types")
    return list(raw) if isinstance(raw, list) else []


def _serialized_tools(tools: list[dict[str, Any]] | None) -> str:
    raw = json.dumps(tools or DEFAULT_SYNTHETIC_TOOLS)
    return raw.decode() if isinstance(raw, bytes) else raw


def _classify_weka_tool_turn(
    row: dict[str, Any], prev_stop: str | None
) -> tuple[TurnType | None, bool, bool]:
    """Map a WEKA API row onto GuideLLM tool-call columns.

    Each row is one HTTP request. ``stop`` is the model output; ``input_types``
    is what the client added. A ``tool_result`` row is therefore an injection
    for the previous row's tool calls, even when that same row also has
    ``stop: tool_use`` (Claude Code multi-step loop). ``tools_column`` on an
    injection only changes the expected output (``tool_choice=required``).

    When ``input_types`` is absent, a row after ``stop: tool_use`` on the same
    agent chain is treated as ``tool_result``. Explicit ``input_types: ["text"]``
    is not.

    :return: ``(turn_type, include_tools, include_tool_response)``. ``turn_type``
        is ``None`` for ordinary text turns.
    """
    input_types = _weka_input_types(row)
    stop = _weka_stop_reason(row)
    is_tool_call = stop == "tool_use"
    is_tool_result = "tool_result" in input_types
    if not is_tool_result and not input_types and prev_stop == "tool_use":
        is_tool_result = True

    if is_tool_result:
        return "tool_response_injection", is_tool_call, True
    if is_tool_call:
        return "client_tool_call", True, False
    return None, False, False


@dataclass
class _TurnSpec:
    node_id: str
    agent_id: str
    parents: list[ConversationParentRef]
    row: dict[str, Any]
    absolute_t: float
    turn_type: TurnType | None = None
    include_tools: bool = False
    include_tool_response: bool = False


DatasetDeserializerFactory.register_decorator(TraceDatasetDeserializer, "weka")


@TraceFormatRegistry.register("weka")
class WEKATraceFormat(TraceFormatBase):
    """WEKA trace format requires a column for timestamps, prompt token counts,
    ouput token counts and lists of hash IDs.

    Hash IDs are unique identifiers based on the current and previous token
    blocks in a prompt. The relationships of IDs forms a tree, where every first ID
    in a prompt has a parent node of `None`. Parent nodes can have an unbounded
    number of children. Two hash IDs can represent identical blocks of tokens so long
    as they do not share the same parent (previous ID). Per-row ``hash_id_scope``
    of ``"global"`` or omitted shares that table across conversations; ``"local"``
    isolates it to the current conversation.

    Declared ``type: "subagent"`` groups become isolated child chains that
    spawn from the preceding parent API turn (``history_context="new"``) and
    join the following parent API turn (``history_context="last"``). Adjacent
    subagents between the same parent turns run in parallel; the following
    parent waits for all of them.

    ``stop: "tool_use"`` and ``input_types: ["tool_result"]`` map onto the
    existing client tool-call pipeline. Tool schemas and results are not in
    the trace (anonymized); pass ``tools`` / ``tool_response_tokens`` like
    synthetic data, or the default placeholder schema and response are used.
    A ``tool_result`` row that also has ``stop: "tool_use"`` is still an
    injection on the input side and carries ``tools_column`` so the model
    may emit further tool calls.

    For more details, see [the WEKA trace format specification][trace-spec].

    [trace-spec]: https://github.com/callanjfox/agentic-coding-analysis/blob/master/docs/TRACE_FORMAT.md

    Generated prompts match the prompt token count of the row."""

    def __init__(self, config: WEKATraceFormatArgs, dataset: Dataset) -> None:
        self.config = config
        self.dataset = dataset

        self._hash_id_table: dict[int, tuple[int, ...]] = {}
        self._sibling_table: dict[Any, set[tuple[int, ...]]] = {}
        # Filled by each ``__iter__`` pass so mixed subagent/API schemas are
        # not forced through a single HuggingFace Arrow table.
        self._conversations: list[tuple[str, list[dict[str, Any]], str | None]] = []
        self._tools_json = _serialized_tools(config.tools)
        self._tool_response_sampler: Iterator[int] | None = None
        self.requests_col = _find_requests_column(dataset)
        if self.requests_col is None:
            raise DataNotSupportedError(
                "WEKA format: Failed to find requests column or requests was empty"
            )
        # Running min of API times seen during ``__iter__``. In-order files
        # (published WEKA, typical captures) establish the shared origin on
        # the first conversation without a pre-scan.
        self._trace_origin: float | None = None

    def reset_hash_tables(self) -> None:
        """Replace hash tables so this copy does not reuse earlier tokens.

        Local-scope conversations still use throwaway tables in
        ``build_conversation_graph``. The tool-response sampler is reset so
        each pass draws remainder/tool text from that pass's faker.
        """
        self._hash_id_table = {}
        self._sibling_table = {}
        self._tool_response_sampler = None

    def __iter__(self) -> Iterable[Dataset]:
        self._conversations = []
        self._trace_origin = None
        for row in self.dataset:
            conv_id = str(row[self.config.conversation_id_column])
            # File order is spawn/join topology for every request list,
            # including nested subagent groups. Do not sort by timestamp.
            requests = [dict(item) for item in row[self.requests_col]]
            times = _absolute_request_times(
                requests, self.config.timestamp_column, float
            )
            if times:
                min_t = min(times)
                if self._trace_origin is not None and min_t < self._trace_origin:
                    logger.warning(
                        "WEKA conversation '{}' starts earlier than previously "
                        "seen timestamps; the dataset is not ordered "
                        "chronologically, so relative timestamps of "
                        "conversations will be misaligned",
                        conv_id,
                    )
                self._trace_origin = (
                    min_t
                    if self._trace_origin is None
                    else min(self._trace_origin, min_t)
                )
            raw_scope = row.get("hash_id_scope")
            hash_id_scope = str(raw_scope) if raw_scope is not None else None
            index = len(self._conversations)
            self._conversations.append((conv_id, requests, hash_id_scope))
            yield Dataset.from_dict({"_weka_index": [index]})

    def required_columns(self) -> Features:
        return Features(
            {
                self.config.conversation_id_column: Value("string"),
                self.config.hash_ids_column: List(Value("int32")),
            }
        )

    def find_required_columns(self, columns: list[str]) -> list[str]:
        # Only the first API row is searchable here. Missing fields on later
        # conversations are skipped at iteration via InvalidRowError.
        conv_col = self.config.conversation_id_column
        if conv_col not in self.dataset.column_names:
            return [self.config.conversation_id_column]
        required = [col for col in columns if col != conv_col]
        first_api = _first_api_request(self.dataset[self.requests_col][0])
        if first_api is None:
            return required
        return get_missing_columns(required, list(first_api.keys()))

    def has_duration_column(self) -> bool:
        """
        Return whether the first API request includes the duration column.

        WEKA stores request fields inside the requests list, not as dataset
        columns. Only the first API request is checked.

        :return: True when ``config.duration_column`` is on that request
        """
        if self.config.duration_column in self.dataset.column_names:
            return True
        first_api = _first_api_request(self.dataset[self.requests_col][0])
        if first_api is None:
            return False
        return self.config.duration_column in first_api

    def validate_row(self, row: dict) -> None:
        n_in = row[self.config.prompt_tokens_column]
        hash_ids = row.get(self.config.hash_ids_column)
        # Nested request schemas are unified across conversations, so a later
        # record that omitted hash_ids arrives as None rather than a missing key.
        if hash_ids is None:
            raise InvalidRowError(
                f"Missing column values in {self.config.hash_ids_column}"
            )
        n_blocks = len(hash_ids)
        block_size = self.config.hash_id_block_size
        for hash_id in hash_ids:
            if hash_id < 0:
                raise InvalidRowError(f"Hash ID must be non-negative, got {hash_id}")
        expected = n_in / block_size
        if math.floor(expected) != n_blocks and math.ceil(expected) != n_blocks:
            raise InvalidRowError(
                f"Input token count of {n_in} split into blocks of size "
                f"{block_size} full blocks and "
                f"{block_size} full blocks + partially filled "
                f"trailing block does not match given {n_blocks} blocks"
            )

    def create_prompt(
        self,
        row: dict,
        processor: PreTrainedTokenizerBase,
        faker: Faker,
        hash_id_table: dict[int, tuple[int, ...]] | None = None,
        sibling_token_blocks: dict[Any, set[tuple[int, ...]]] | None = None,
    ) -> str:
        """Before generating the prompt, this first generates a block of tokens for
        each hash ID that has not already been seen.

        Hash IDs that are partially filled are discarded to match the specification.
        Remainder of the prompt is created after the creation via hash IDs token
        blocks.

        :param hash_id_table: Token blocks keyed by hash ID. Instance storage for
            global scope, or a throwaway dict for local scope. Defaults to the
            current copy's table.
        :param sibling_token_blocks: Distinctness set per previous hash ID, matching
            ``hash_id_table``'s lifetime. Defaults to the current copy's set.
        """
        if hash_id_table is None:
            hash_id_table = self._hash_id_table
        if sibling_token_blocks is None:
            sibling_token_blocks = self._sibling_table
        ids = row[self.config.hash_ids_column]
        n_in = row[self.config.prompt_tokens_column]
        block_size = self.config.hash_id_block_size
        expected = n_in / block_size
        if math.floor(expected) != len(ids) and math.ceil(expected) == len(ids):
            ids.pop()
        fill_hash_id_table(
            ids,
            hash_id_table,
            sibling_token_blocks,
            processor,
            faker,
            lambda _idx, _hash_id: block_size,
        )
        prompt = create_prompt_from_hash_ids(ids, hash_id_table, processor)
        remainder = _generate_remaining_prompt(n_in % block_size, processor, faker)
        if not prompt:
            return remainder
        if not remainder:
            return prompt
        return f"{prompt} {remainder}"

    def build_conversation_graph(
        self,
        conversation: Dataset,
        processor: PreTrainedTokenizerBase,
        faker: Faker,
    ) -> ConversationGraphData:
        conv_id, requests, hash_id_scope = self._unpack_conversation(conversation)
        # Local scope uses throwaway tables so this conversation cannot reuse
        # or pollute the instance-level hash storage used by global/unset rows.
        if hash_id_scope == "local":
            hash_id_table: dict[int, tuple[int, ...]] = {}
            sibling_token_blocks: dict[Any, set[tuple[int, ...]]] = {}
        else:
            hash_id_table = self._hash_id_table
            sibling_token_blocks = self._sibling_table
        specs, _last = self._emit_chain(
            requests,
            agent_id="default",
            node_prefix="main",
            preceding_parent_id=None,
            first_turn_history="new",
            t_transform=lambda t: t,
            spawn_seq=[0],
            conversation_id=conv_id,
        )
        if not specs:
            raise InvalidRowError(
                "WEKA format: conversation has no API requests to replay"
            )
        # One pass builds turns and stops at the first turn that would exceed
        # the context budget, before prompt generation. The dataset origin is
        # already known, so relative timestamps are written in this same pass.
        max_len = self.config.max_context_len
        prompt_col = self.config.prompt_tokens_column
        output_col = self.config.output_tokens_column
        origin = 0.0 if self._trace_origin is None else self._trace_origin
        running_tokens = 0
        turns: list[ConversationTurnData] = []
        for index, spec in enumerate(specs):
            if max_len is not None:
                turn_tokens = int(spec.row[prompt_col]) + int(spec.row[output_col])
                if running_tokens + turn_tokens > max_len:
                    logger.debug(
                        "WEKA conversation '{}' truncated: discarding {} "
                        "turn(s) starting at node '{}' (turn tokens={}, "
                        "running={})",
                        conv_id,
                        len(specs) - index,
                        spec.node_id,
                        turn_tokens,
                        running_tokens,
                    )
                    if len(turns) < 1:
                        return ConversationGraphData(turns=[])
                    break
                running_tokens += turn_tokens
            _validate_api_row(spec.row, self.config, self.validate_row)
            prompt = self.create_prompt(
                spec.row,
                processor,
                faker,
                hash_id_table,
                sibling_token_blocks,
            )
            columns: dict[str, Any] = {
                "text_column": [prompt],
                "prompt_tokens_count_column": [spec.row[prompt_col]],
                "output_tokens_count_column": [spec.row[output_col]],
                "relative_timestamp_column": [spec.absolute_t - origin],
                **duration_columns(spec.row, self.config),
            }
            if spec.turn_type is not None:
                columns["turn_type_column"] = [spec.turn_type]
            if spec.include_tools:
                columns["tools_column"] = [self._tools_json]
            if spec.include_tool_response:
                columns["tool_response_column"] = [
                    self._tool_response_text(processor, faker)
                ]
            turns.append(
                ConversationTurnData(
                    node_id=spec.node_id,
                    agent_id=spec.agent_id,
                    parents=spec.parents,
                    columns=columns,
                )
            )
        return ConversationGraphData(turns=turns)

    def _tool_response_text(
        self, processor: PreTrainedTokenizerBase, faker: Faker
    ) -> str:
        """Build the mocked tool result for an injection turn.

        Matches synthetic data: ``tool_response_tokens`` sizes a ``{"result": ...}``
        payload; otherwise the global placeholder is used.
        """
        if self.config.tool_response_tokens is None:
            return settings.default_synthetic_tool_response
        if self._tool_response_sampler is None:
            self._tool_response_sampler = iter(
                IntegerRangeSampler(
                    average=self.config.tool_response_tokens,
                    variance=self.config.tool_response_tokens_stdev,
                    min_value=self.config.tool_response_tokens_min,
                    max_value=self.config.tool_response_tokens_max,
                    random_seed=faker.random.getrandbits(32),
                )
            )
        body = _generate_remaining_prompt(
            next(self._tool_response_sampler), processor, faker
        )
        raw = json.dumps({"result": body})
        return raw.decode() if isinstance(raw, bytes) else raw

    def _unpack_conversation(
        self, conversation: Dataset
    ) -> tuple[str, list[dict[str, Any]], str | None]:
        """Look up the nested request list for a conversation stub from ``__iter__``.

        The ``requests`` column mixes API request records with
        ``type: "subagent"`` groups, which cannot share one Arrow schema, so
        ``__iter__`` does not put that list into the yielded Dataset. It
        appends ``(conversation_id, requests, hash_id_scope)`` to
        ``self._conversations`` and yields a Dataset with a single row and a
        single column, ``_weka_index``.

        ``conversation[0]`` is the only row in the yielded Dataset.
        ``_weka_index`` is the integer index of the matching entry in
        ``self._conversations``.

        :param conversation: One-row Dataset yielded by ``__iter__``.
        :return: ``(conversation_id, requests, hash_id_scope)`` for that
            conversation. ``hash_id_scope`` is ``None`` when the field is omitted.
        """
        index = int(conversation[0]["_weka_index"])
        return self._conversations[index]

    def _emit_chain(
        self,
        requests: list[dict[str, Any]],
        agent_id: str,
        node_prefix: str,
        preceding_parent_id: str | None,
        first_turn_history: HistoryContext,
        t_transform: Callable[[float], float],
        spawn_seq: list[int],
        conversation_id: str,
    ) -> tuple[list[_TurnSpec], str | None]:
        """Walk a request list into turn specs for one agent plus its children.

        File order is spawn/join topology. API rows continue this agent's
        chain. ``type: "subagent"`` groups spawn a sibling chain from the
        latest API turn of this agent (``history_context="new"``). The next
        API turn of this agent joins every pending sibling
        (``history_context="last"``), so multiple subagents between the same
        parent turns run in parallel. Nested subagent groups keep the same
        rule against the inner list.
        """
        ts_col = self.config.timestamp_column
        specs: list[_TurnSpec] = []
        pending_join_ids: list[str] = []
        last_chain_id: str | None = None
        chain_idx = 0
        # Previous API row's stop on this chain only. Subagent children are
        # interleaved in the flattened spec list, so classification cannot
        # use that list's adjacency.
        prev_stop: str | None = None
        prev_event: tuple[float, float | None] | None = None

        for item in requests:
            if _is_subagent_entry(item):
                inner = [dict(row) for row in (item.get("requests") or [])]
                if not inner:
                    continue
                spawn_id = spawn_seq[0]
                spawn_seq[0] += 1
                child_agent = str(item.get("agent_id") or f"sa_{spawn_id}")
                if last_chain_id is None:
                    logger.warning(
                        "WEKA subagent '{}' in conversation '{}' has no "
                        "preceding parent turn; replaying as an independent root",
                        child_agent,
                        conversation_id,
                    )
                child_specs, child_last = self._emit_chain(
                    inner,
                    agent_id=child_agent,
                    node_prefix=f"sa_{spawn_id}",
                    preceding_parent_id=last_chain_id,
                    first_turn_history="new",
                    t_transform=_inner_timestamp_transform(item, inner, ts_col),
                    spawn_seq=spawn_seq,
                    conversation_id=conversation_id,
                )
                specs.extend(child_specs)
                if child_last is not None:
                    pending_join_ids.append(child_last)
                continue

            parents: list[ConversationParentRef] = []
            if last_chain_id is not None:
                parents.append(
                    ConversationParentRef(
                        parent_node_id=last_chain_id,
                        history_context="full",
                    )
                )
            elif preceding_parent_id is not None:
                parents.append(
                    ConversationParentRef(
                        parent_node_id=preceding_parent_id,
                        history_context=first_turn_history,
                    )
                )
            for join_id in pending_join_ids:
                parents.append(
                    ConversationParentRef(
                        parent_node_id=join_id,
                        history_context="last",
                    )
                )
            pending_join_ids = []

            abs_t = t_transform(float(item[ts_col]))
            node_id = f"{node_prefix}_{chain_idx}"
            turn_type, include_tools, include_tool_response = _classify_weka_tool_turn(
                item, prev_stop
            )
            specs.append(
                _TurnSpec(
                    node_id=node_id,
                    agent_id=agent_id,
                    parents=parents,
                    row=_copy_api_row(item, self.config.hash_ids_column),
                    absolute_t=abs_t,
                    turn_type=turn_type,
                    include_tools=include_tools,
                    include_tool_response=include_tool_response,
                )
            )
            last_chain_id = node_id
            chain_idx += 1
            event = (abs_t, _optional_float(item.get("api_time")))
            self._warn_chain_overlap(conversation_id, agent_id, prev_event, event)
            prev_event = event
            prev_stop = _weka_stop_reason(item)

        if pending_join_ids:
            logger.debug(
                "WEKA subagent(s) in conversation '{}' on agent '{}' have no "
                "following parent turn; replaying as background without a join",
                conversation_id,
                agent_id,
            )

        return specs, last_chain_id

    def _warn_chain_overlap(
        self,
        conversation_id: str,
        agent_id: str,
        prev_event: tuple[float, float | None] | None,
        event: tuple[float, float | None],
    ) -> None:
        """Warn when consecutive turns of one agent overlap in time.

        Published WEKA traces include consecutive same-agent turns whose
        ``api_time`` windows overlap; those turns are serialized on one chain.
        Overlap uses recorded ``api_time`` when present
        (``t[i] + api_time[i] > t[i+1]``), otherwise non-increasing start
        times. Parallel subagents overlapping each other is intended and
        is not warned here; each agent chain is checked separately.
        """
        if prev_event is None:
            return
        t_i, api_time = prev_event
        t_next, _ = event
        overlapped = t_i + api_time > t_next if api_time is not None else t_next <= t_i
        if not overlapped:
            return
        if api_time is not None:
            logger.debug(
                "WEKA conversation '{}' agent '{}' has overlapping requests: "
                "the request at t={} will run until t={}, which is after "
                "the next request at t={}; they will be serialized on "
                "this chain",
                conversation_id,
                agent_id,
                t_i,
                t_i + api_time,
                t_next,
            )
        else:
            logger.debug(
                "WEKA conversation '{}' agent '{}' has overlapping requests: "
                "the request at t={} is followed by a request at t={} "
                "that does not start later; they will be serialized on "
                "this chain",
                conversation_id,
                agent_id,
                t_i,
                t_next,
            )
