from __future__ import annotations

from typing import Literal, TypeAlias

from datasets import Dataset, DatasetDict, IterableDataset, IterableDatasetDict

__all__ = [
    "DataNotSupportedError",
    "DatasetDictType",
    "DatasetType",
    "GenerativeDatasetColumnType",
    "InvalidRowError",
]


GenerativeDatasetColumnType = Literal[
    "prompt_tokens_count_column",
    "output_tokens_count_column",
    "prefix_column",
    "text_column",
    "raw_messages_column",
    "image_column",
    "video_column",
    "audio_column",
    "tools_column",
    "tool_response_column",
    "tool_choice_column",
    "turn_type_column",
    "relative_timestamp_column",
    "requeue_delay_column",
    "request_duration_column",
    "conversation_turns_column",
]

DatasetType: TypeAlias = Dataset | IterableDataset


DatasetDictType: TypeAlias = DatasetType | DatasetDict | IterableDatasetDict


class DataNotSupportedError(Exception):
    """
    Exception raised when the data format is not supported by deserializer or config.
    """


class InvalidRowError(Exception):
    """A single dataset row failed validation and should be skipped."""
