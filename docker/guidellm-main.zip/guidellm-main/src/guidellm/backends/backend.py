"""
Backend interface and registry for generative AI model interactions.

Provides the abstract base class for implementing backends that communicate with
generative AI models. Backends handle the lifecycle of generation requests and
provide a standard interface for distributed execution across worker processes.
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, ClassVar

from guidellm.scheduler import BackendInterface
from guidellm.schemas import GenerationRequest, GenerationResponse
from guidellm.schemas.backends import BackendArgs
from guidellm.utils.registry import RegistryMixin

__all__ = [
    "Backend",
]


class Backend(
    RegistryMixin["type[Backend]"],
    BackendInterface[GenerationRequest, GenerationResponse],
):
    """
    Base class for generative AI backends with registry and lifecycle management.

    Provides a standard interface for backends that communicate with generative AI
    models. Combines the registry pattern for automatic discovery with a defined
    lifecycle for process-based distributed execution. Backend state must be
    pickleable for distributed execution across process boundaries.

    Backend lifecycle phases:
    1. Creation and configuration
    2. Process startup - Initialize resources in worker process
    3. Validation - Verify backend readiness
    4. Request resolution - Process generation requests
    5. Process shutdown - Clean up resources

    Example:
    ::
        @Backend.register("my_backend")
        class MyBackend(Backend):
            def __init__(self, args: MyBackendArgs):
                super().__init__(args)
                self.api_key = args.api_key

            async def process_startup(self):
                self.client = MyAPIClient(self.api_key)

        args = MyBackendArgs(api_key="secret")
        backend = Backend.create(args)
    """

    _args: BackendArgs

    @classmethod
    def create(cls, args: BackendArgs) -> Backend:
        """
        Create a backend instance based on the backend type.

        :param type_: The type of backend to create
        :param kwargs: Additional arguments for backend initialization
        :return: An instance of a subclass of Backend
        :raises ValueError: If the backend type is not registered
        """
        kind = args.kind

        backend = cls.get_registered_object(kind)

        if backend is None:
            raise ValueError(
                f"Backend type '{kind}' is not registered. "
                f"Available types: {list(cls.registry.keys()) if cls.registry else []}"
            )

        return backend(args)

    def __init__(self, args: BackendArgs):
        """
        Initialize a backend instance.

        :param args: The backend arguments object
        """
        self.kind = args.kind
        self._args = args

    @property
    def info(self) -> dict[str, Any]:
        """
        Return a snapshot of backend configuration for logging or debugging.
        """
        return self._args.model_dump(mode="json") if self._args else {}

    @property
    def processes_limit(self) -> int | None:
        """
        :return: Maximum number of worker processes supported, None if unlimited
        """
        return None

    @property
    def request_models(self) -> list[str]:
        """
        Models that requests are routed to, for round-robin distribution.

        Base implementation returns the single configured model. Backends
        serving multiple models on one endpoint (e.g. LoRA adapters)
        override this to return the full cycle list.

        :return: List of model names (empty when no model is configured)
        """
        model = getattr(self._args, "model", "") if self._args else ""
        return [model] if model else []

    @property
    def requests_limit(self) -> int | None:
        """
        :return: Maximum number of concurrent requests supported globally,
            None if unlimited
        """
        return None

    #: Whether GuideLLM already knows this backend's default model from its
    #: configuration, without querying a running engine. When ``True``,
    #: ``resolve_backend`` reads the model directly and does not start the backend
    #: in the main process. When ``False`` (the default), the backend must be
    #: started to discover its model. This is independent of validation: workers
    #: always start and validate the engine before making requests.
    backend_defines_model: ClassVar[bool] = False

    @abstractmethod
    async def default_model(self) -> str:
        """
        :return: The default model name or identifier for generation requests,
        """
        ...
