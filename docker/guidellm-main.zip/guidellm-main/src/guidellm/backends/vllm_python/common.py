"""Shared utilities for vLLM Python backends."""

from __future__ import annotations

import multiprocessing as mp
import os
import sys
from pathlib import Path
from typing import Any

from guidellm.logger import logger

__all__ = [
    "is_scheduler_worker_process",
    "reset_cpu_affinity",
    "vllm_benchmark_engine_config",
]


def is_scheduler_worker_process() -> bool:
    """Return True when running inside a GuideLLM scheduler worker process."""
    return mp.parent_process() is not None


def vllm_benchmark_engine_config(
    vllm_config: dict[str, Any],
) -> dict[str, Any]:
    """Return a copy of ``vllm_config`` with benchmark-friendly defaults."""
    config = dict(vllm_config)
    config.setdefault("disable_log_stats", True)
    return config


def reset_cpu_affinity() -> None:
    """Restore the full CPU set allowed by the OS/cgroup.

    When the worker process is forked from a parent that has
    already initialised an OpenMP runtime (e.g. via PyTorch),
    the child inherits a restricted CPU-affinity mask.  This
    causes vLLM's auto-bind logic to see far fewer cores than
    are actually available, destroying throughput.

    We read the effective cpuset from the cgroup filesystem
    and reset the affinity to the full set.
    """
    if sys.platform != "linux":
        return

    current = os.sched_getaffinity(0)

    # Try cgroup v2 first, then fall back to cgroup v1.
    # The `return` at the end of the loop body (outside the `if`) means
    # "stop after the first path that is readable" — OSError on a path
    # causes `continue` to the next, but a successful read always exits.
    for path_str in (
        "/sys/fs/cgroup/cpuset.cpus.effective",
        "/sys/fs/cgroup/cpuset/cpuset.cpus",
    ):
        try:
            raw = Path(path_str).read_text().strip()
        except OSError:
            continue

        cpus: set[int] = set()
        for part in raw.split(","):
            if "-" in part:
                lo, hi = part.split("-", 1)
                cpus.update(range(int(lo), int(hi) + 1))
            else:
                cpus.add(int(part))

        if cpus and current != cpus:
            os.sched_setaffinity(0, cpus)
            logger.debug(
                "Reset CPU affinity from {} to {} cores",
                len(current),
                len(cpus),
            )
        return
