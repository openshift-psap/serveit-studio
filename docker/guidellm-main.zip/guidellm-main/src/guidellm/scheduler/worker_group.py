"""
Multi-process worker group orchestration for distributed request scheduling.

Provides infrastructure for coordinating worker processes with shared state
management, inter-process communication, and lifecycle coordination. Handles
dynamic scaling, load balancing, constraint evaluation, and graceful shutdown
across distributed workers processing concurrent requests.
"""

from __future__ import annotations

import asyncio
import contextlib
import math
import threading
import time
import uuid
from collections.abc import AsyncIterator, Generator
from multiprocessing import get_context
from multiprocessing.context import BaseContext
from multiprocessing.managers import BaseManager
from multiprocessing.process import BaseProcess
from multiprocessing.synchronize import Barrier, Event
from typing import Generic, NamedTuple

from typing_extensions import TypeAliasType

from guidellm.logger import logger
from guidellm.scheduler.constraints import Constraint, RequestsExhaustedConstraint
from guidellm.scheduler.dag import DAGExecutionState
from guidellm.scheduler.schemas import (
    BackendInterface,
    ConversationT,
    DatasetIterT,
    RequestT,
    ResponseT,
    SchedulerState,
    SchedulerUpdateAction,
)
from guidellm.scheduler.strategies import SchedulingStrategy
from guidellm.scheduler.worker import WorkerProcess
from guidellm.schemas import RequestInfo
from guidellm.settings import settings
from guidellm.utils.messaging import (
    InterProcessMessaging,
    InterProcessMessagingManagerQueue,
    InterProcessMessagingPipe,
    InterProcessMessagingQueue,
)
from guidellm.utils.pipe_stdout import PipeReaderThread
from guidellm.utils.synchronous import wait_for_sync_objects

__all__ = ["WorkerGroupState", "WorkerProcessGroup"]

WorkGroupMessengerT = TypeAliasType(
    "WorkGroupMessengerT",
    InterProcessMessaging[
        ConversationT[RequestT],
        tuple[
            ResponseT | None,
            RequestT,
            RequestInfo,
            SchedulerState,
        ],
    ],
    type_params=(RequestT, ResponseT),
)
"""
IPC types from the prespective of the WorkerProcessGroup, which sends Conversations
and receives (Response, Request, RequestInfo, SchedulerState) tuples.
"""


class WorkerProcessGroup(Generic[RequestT, ResponseT]):
    """
    Orchestrates multiple worker processes for distributed request processing.

    Manages process lifecycle, request distribution, response collection, and state
    synchronization across workers. Handles dynamic scaling, load balancing, and
    constraint evaluation with graceful shutdown coordination for high-throughput
    request processing workloads.

    Example:
    ::
        from guidellm.scheduler.worker_group import WorkerProcessGroup

        group = WorkerProcessGroup(
            requests=request_iterable,
            backend=backend_instance,
            strategy=scheduling_strategy,
            constraints={"max_time": time_constraint}
        )

        await group.create_processes()
        await group.start(time.time())

        async for response, request, info, state in group.request_updates():
            if response is not None:
                # Process completed request
                handle_response(response)

        await group.shutdown()
    """

    def __init__(
        self,
        requests: DatasetIterT[RequestT],
        backend: BackendInterface[RequestT, ResponseT],
        strategy: SchedulingStrategy,
        **constraints: Constraint,
    ):
        """
        Initialize a worker process group for distributed request processing.

        :param requests: Finite iterable of requests to process sequentially
        :param backend: Backend interface for processing requests
        :param strategy: Scheduling strategy for request timing and distribution
        :param constraints: Named constraints for controlling execution behavior
        """
        self.requests = iter(requests)
        self.backend = backend
        self.strategy = strategy
        self.constraints = constraints

        # Multiprocessing contexts and primitives, created in create_processes
        self.mp_context: BaseContext | None = None
        self.mp_manager: BaseManager | None = None
        self.processes: list[BaseProcess] | None = None
        self.startup_barrier: Barrier | None = None
        self.requests_generated_event: Event | None = None
        self.constraint_reached_event: Event | None = None
        self.shutdown_event: Event | None = None
        self.error_event: Event | None = None

        # Background health monitor, created in create_processes
        self._health_monitor_task: asyncio.Task | None = None
        self._worker_error_details: str | None = None

        # Pipe-based stdout/stderr capture, created in create_processes
        self._pipe_reader_thread: PipeReaderThread | None = None

        # Scheduler and messaging state, created in start
        self.state: WorkerGroupState[RequestT, ResponseT] | None = None
        self.messaging: WorkGroupMessengerT[RequestT, ResponseT] | None = None

    async def create_processes(self):
        """
        Create and initialize worker processes for distributed request processing.

        Sets up multiprocessing infrastructure and worker processes based on
        strategy constraints, backend capabilities, and system configuration.
        Determines optimal process count and concurrency limits, then spawns
        worker processes with distributed request handling capabilities.

        :raises RuntimeError: If process initialization or startup fails
        """
        # Processes limits and params
        max_conc: int
        if (
            requests_limit := min(
                self.strategy.requests_limit or math.inf,
                self.backend.requests_limit or math.inf,
            )
        ) != math.inf:
            max_conc = int(requests_limit)
        else:
            # If concurrency not specified, use settings
            max_conc = settings.max_concurrency
        if max_conc <= 0:
            raise RuntimeError("max_concurrency resolved to 0; increase limits/config")

        # Calculate number of processes, ensure we don't exceed the max concurrency,
        # or limits from the backend, strategy, or user settings
        num_processes: int = int(
            min(
                max_conc,
                self.strategy.processes_limit or math.inf,
                self.backend.processes_limit or math.inf,
                settings.max_worker_processes,
            )
        )
        if num_processes <= 0:
            raise RuntimeError("num_processes resolved to 0; increase limits/config")

        per_proc_max_conc = max_conc // num_processes
        max_pending_size = max(
            1, math.floor(max_conc * settings.mp_max_pending_buffer_percent)
        )
        per_proc_max_buffer_size = 1

        # Initialize multiprocessing components
        self.mp_context = get_context(settings.mp_context_type)
        self.mp_manager = self.mp_context.Manager()
        self.startup_barrier = self.mp_context.Barrier(num_processes + 1)
        self.requests_generated_event = self.mp_context.Event()
        self.constraint_reached_event = self.mp_context.Event()
        self.shutdown_event = self.mp_context.Event()
        self.error_event = self.mp_context.Event()

        if settings.mp_messaging_object == "queue":
            self.messaging = InterProcessMessagingQueue(
                mp_context=self.mp_context,
                serialization=settings.mp_serialization,
                encoding=settings.mp_encoding,
                max_pending_size=max_pending_size,
                max_buffer_send_size=settings.mp_requests_send_buffer_size,
                poll_interval=settings.mp_poll_interval,
            )
        elif settings.mp_messaging_object == "manager_queue":
            self.messaging = InterProcessMessagingManagerQueue(
                manager=self.mp_manager,
                mp_context=self.mp_context,
                serialization=settings.mp_serialization,
                encoding=settings.mp_encoding,
                max_pending_size=max_pending_size,
                max_buffer_send_size=settings.mp_requests_send_buffer_size,
                poll_interval=settings.mp_poll_interval,
            )
        elif settings.mp_messaging_object == "pipe":
            self.messaging = InterProcessMessagingPipe(
                num_workers=num_processes,
                mp_context=self.mp_context,
                serialization=settings.mp_serialization,
                encoding=settings.mp_encoding,
                max_pending_size=max_pending_size,
                max_buffer_send_size=settings.mp_requests_send_buffer_size,
                poll_interval=settings.mp_poll_interval,
            )

        # Create shared pipes for capturing worker stdout/stderr
        stdout_reader, stdout_writer = self.mp_context.Pipe(duplex=False)
        stderr_reader, stderr_writer = self.mp_context.Pipe(duplex=False)

        # Initialize worker processes
        self.processes = []
        self.strategy.init_processes_timings(
            worker_count=num_processes,
            max_concurrency=max_conc,
            mp_context=self.mp_context,
        )
        for rank in range(num_processes):
            # Distribute any remainder across the first N ranks
            async_limit = per_proc_max_conc + (
                1 if rank < (max_conc % num_processes) else 0
            )

            worker = WorkerProcess[RequestT, ResponseT](
                worker_index=rank,
                messaging=self.messaging.create_worker_copy(  # type: ignore[arg-type]
                    worker_index=rank,
                    max_buffer_send_size=None,
                    max_buffer_receive_size=per_proc_max_buffer_size,
                ),  # The non-group worker lacks the SchedulerState type. Type err.
                backend=self.backend,
                strategy=self.strategy,
                async_limit=async_limit,
                fut_scheduling_time_limit=0.0,
                startup_barrier=self.startup_barrier,
                requests_generated_event=self.requests_generated_event,
                constraint_reached_event=self.constraint_reached_event,
                shutdown_event=self.shutdown_event,
                error_event=self.error_event,
                stdout_conn=stdout_writer,
                stderr_conn=stderr_writer,
                parent_logger=logger,
            )
            proc = self.mp_context.Process(target=worker.run, daemon=False)
            proc.start()
            self.processes.append(proc)

        # Close write-ends in parent so EOF fires when last worker exits
        stdout_writer.close()
        stderr_writer.close()

        # Start reader thread to route worker output through main sys.stdout/stderr
        self._pipe_reader_thread = PipeReaderThread(stdout_reader, stderr_reader)
        self._pipe_reader_thread.start()

        self._health_monitor_task = asyncio.create_task(self._process_health_monitor())

        wait_key = await wait_for_sync_objects(
            {
                "startup_barrier": self.startup_barrier,
                "shutdown_event": self.shutdown_event,
                "error_event": self.error_event,
            },
            poll_interval=settings.mp_poll_interval,
        )

        if wait_key == "error_event":
            detail = self._worker_error_details or "error_event is set"
            raise RuntimeError(f"Worker process group startup failed: {detail}")

    async def _process_health_monitor(self):
        """Detect worker processes killed by OS signals (e.g. SIGSEGV, OOM)
        that bypass Python exception handling and never set error_event."""
        while self.processes:
            await asyncio.sleep(settings.mp_poll_interval)
            dead: list[str] = []
            killed_by_signal = False
            for proc in self.processes:
                if (
                    not proc.is_alive()
                    and proc.exitcode is not None
                    and proc.exitcode != 0
                ):
                    if proc.exitcode < 0:
                        killed_by_signal = True
                        exit_info = f"signal {-proc.exitcode}"
                    else:
                        exit_info = f"exit code {proc.exitcode}"
                    detail = (
                        f"Worker process {proc.pid} died unexpectedly ({exit_info})"
                    )
                    logger.error(detail)
                    dead.append(detail)

            if dead:
                message = "; ".join(dead)
                if killed_by_signal:
                    message += (
                        ". Check system logs and "
                        "docs/guides/troubleshooting.md for details"
                    )
                self._worker_error_details = message
                if self.error_event is not None:
                    self.error_event.set()
                return

    async def start(self, start_time: float):
        """
        Begin request processing at the specified start time.

        Initializes scheduler state and background tasks, then waits until the
        specified start time before beginning operations. Sets up inter-process
        communication and coordinates synchronized startup across all workers.

        :param start_time: Unix timestamp when processing should begin
        :raises RuntimeError: If workers encounter errors during startup or
            if create_processes() was not called first
        """
        if (
            not self.processes
            or not self.requests_generated_event
            or not self.constraint_reached_event
            or not self.shutdown_event
            or not self.error_event
            or not self.messaging
        ):
            raise RuntimeError("create_processes() must be called before start()")

        self.strategy.init_processes_start(start_time=start_time)
        stop_send_requests_event = threading.Event()
        send_requests_stopped_event = threading.Event()
        self.state = WorkerGroupState[RequestT, ResponseT](
            start_time=start_time,
            processes=self.processes,
            strategy=self.strategy,
            constraints=self.constraints,
            stop_send_requests_event=stop_send_requests_event,
            send_requests_stopped_event=send_requests_stopped_event,
            requests_generated_event=self.requests_generated_event,
            constraint_reached_event=self.constraint_reached_event,
            shutdown_event=self.shutdown_event,
            error_event=self.error_event,
            messaging=self.messaging,
        )
        backend_model = ""
        if self.backend and self.backend._args:  # noqa: SLF001
            backend_model = self.backend._args.model  # noqa: SLF001
        request_models = (
            [m.strip() for m in backend_model.split(",") if m.strip()]
            if backend_model and "," in backend_model
            else None
        )
        await self.messaging.start(
            send_items=self.state.requests_generator(
                self.requests,
                request_models=request_models,
            ),
            receive_callback=self.state.received_callback,
            send_stopped_event=send_requests_stopped_event,
            send_stop_criteria=[stop_send_requests_event],
            receive_stop_criteria=[self.shutdown_event],
        )

        if (wait_time := start_time - time.time()) > 0:
            await asyncio.sleep(wait_time)
        if self.error_event.is_set():
            detail = (
                self._worker_error_details
                or "an error occurred in one of the worker processes"
            )
            raise RuntimeError(f"error_event is set in WorkerProcessGroup: {detail}")

    async def request_updates(
        self,
    ) -> AsyncIterator[
        tuple[
            ResponseT | None,
            RequestT,
            RequestInfo,
            SchedulerState,
        ]
    ]:
        """
        Yield request processing updates as they become available.

        Returns an async iterator of request updates including response, request,
        request scheduling info, and scheduler state. Updates occur on request queued,
        processing start, and completion. Response is None until processing completes.

        :return: Async iterator yielding (response, request, request_info, state)
            tuples where response is None until processing is complete
        :raises RuntimeError: If workers encounter unrecoverable errors
        """
        while True:
            if self.error_event.is_set():  # type: ignore[union-attr]
                logger.error("Error event set in WorkerProcessGroup")
                detail = (
                    self._worker_error_details
                    or "an error occurred in one of the worker processes"
                )
                raise RuntimeError(
                    f"error_event is set in WorkerProcessGroup: {detail}"
                )

            try:
                (
                    response,
                    request,
                    request_info,
                    scheduler_state,
                ) = await self.messaging.get(timeout=settings.mp_poll_interval)  # type: ignore[union-attr]

                yield response, request, request_info, scheduler_state
            except asyncio.TimeoutError:
                if self.shutdown_event.is_set():  # type: ignore[union-attr]
                    # Everything yielded, exit
                    break
                # Time-based constraints (max_duration) must be evaluated even when
                # workers are sleeping until a future target start, because no
                # request updates arrive during that wait.
                if self.state is not None:
                    state_update = self.state.update_state()
                    if (
                        state_update.stop_processing
                        and self.constraint_reached_event is not None
                    ):
                        self.constraint_reached_event.set()
                    if state_update.stop_queueing:
                        self.state.stop_send_requests_event.set()

    async def shutdown(self) -> list[Exception]:
        """
        Gracefully shut down the worker process group and clean up resources.

        Performs safe shutdown of worker processes, background tasks, and
        multiprocessing resources. Coordinates orderly termination across
        all workers and collects any exceptions encountered during shutdown.
        Workers that ignore the shutdown event are terminated, then killed,
        so ``Manager.shutdown`` cannot block indefinitely on live connections.

        :return: List of exceptions encountered during shutdown; empty if no errors
        """
        exceptions: list[Exception] = []

        if self._health_monitor_task is not None:
            self._health_monitor_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._health_monitor_task
            self._health_monitor_task = None

        if self.shutdown_event is not None:
            self.shutdown_event.set()

        # Clear out start values
        if self.messaging is not None:
            try:
                await asyncio.wait_for(self.messaging.stop(), timeout=5.0)
            except Exception as err:  # noqa: BLE001
                exceptions.append(err)
        self.messaging = None
        self.state = None

        # Clear out create processes values
        if self.processes is not None:
            join_errors = await asyncio.gather(
                *[self._join_or_kill_process(proc) for proc in self.processes]
            )
            exceptions.extend(err for err in join_errors if err is not None)
        self.processes = None

        if self._pipe_reader_thread is not None:
            self._pipe_reader_thread.stop()
            self._pipe_reader_thread = None

        self.startup_barrier = None
        self.requests_generated_event = None
        self.constraint_reached_event = None
        self.shutdown_event = None
        self.error_event = None
        if self.mp_manager is not None:
            try:
                # Enforce a time limit because a live worker holding a Manager
                # connection can otherwise block here until the process is
                # killed externally.
                await asyncio.wait_for(
                    asyncio.to_thread(self.mp_manager.shutdown),
                    timeout=5.0,
                )
            except Exception as err:  # noqa: BLE001
                exceptions.append(err)
        self.mp_manager = None
        self.mp_context = None

        return exceptions

    async def _join_or_kill_process(self, proc: BaseProcess) -> Exception | None:
        """Join a worker, then terminate and kill if it does not exit.

        :param proc: Worker process to wait for
        :return: Abnormal-exit error if the process exited on its own with a
            non-zero code; ``None`` if it exited cleanly or was force-stopped
        """
        try:
            await asyncio.to_thread(proc.join, timeout=5.0)
            force_stopped = False
            if proc.is_alive():
                proc.terminate()
                await asyncio.to_thread(proc.join, timeout=2.0)
                force_stopped = True
            if proc.is_alive():
                proc.kill()
                await asyncio.to_thread(proc.join, timeout=2.0)
                force_stopped = True
            if not force_stopped and proc.exitcode is not None and proc.exitcode != 0:
                exit_info = (
                    f"signal {-proc.exitcode}"
                    if proc.exitcode < 0
                    else f"exit code {proc.exitcode}"
                )
                return RuntimeError(
                    f"Worker {proc.pid} exited abnormally ({exit_info})"
                )
        except Exception as err:  # noqa: BLE001
            return err
        return None


class _StateUpdate(NamedTuple):
    """Internal state update result with control flags."""

    state: SchedulerState
    stop_queueing: bool
    stop_processing: bool


class _ModelCycle:
    """Round-robin model assignment for comma-separated model lists.

    Assigned in the main scheduler process at request-generation time,
    before worker dispatch — immune to multiprocessing isolation.
    """

    def __init__(self, models: list[str]):
        self._models = models
        self._index = 0

    def assign(self, request) -> None:
        if not self._models:
            return
        request.model = self._models[self._index]
        self._index = (self._index + 1) % len(self._models)


class WorkerGroupState(Generic[RequestT, ResponseT]):
    """
    Manages scheduler state and synchronization for worker process groups.

    Handles request generation, state updates, constraint evaluation, and
    coordination between worker processes. Provides thread-safe state management
    with request lifecycle tracking and constraint-based termination logic.
    """

    def __init__(
        self,
        start_time: float,
        processes: list[BaseProcess],
        strategy: SchedulingStrategy,
        constraints: dict[str, Constraint],
        stop_send_requests_event: threading.Event,
        send_requests_stopped_event: threading.Event,
        requests_generated_event: Event,
        constraint_reached_event: Event,
        shutdown_event: Event,
        error_event: Event,
        messaging: WorkGroupMessengerT[RequestT, ResponseT],
    ):
        """
        Initialize worker group state management.

        :param start_time: Unix timestamp when processing should begin
        :param processes: List of worker process instances
        :param strategy: Scheduling strategy for request timing at dequeue
        :param constraints: Named constraints for controlling execution behavior
        :param stop_send_requests_event: Threading event for stopping request generation
        :param send_requests_stopped_event: Threading event for request coordination
        :param requests_generated_event: Multiprocessing event for generation completion
        :param constraint_reached_event: Multiprocessing event for constraint stopping
        :param shutdown_event: Multiprocessing event for coordinated shutdown
        :param error_event: Multiprocessing event for error condition signaling
        """
        self.start_time = start_time
        self.processes = processes
        self.strategy = strategy
        self.constraints = constraints
        self.stop_send_requests_event = stop_send_requests_event
        self.send_requests_stopped_event = send_requests_stopped_event
        self.requests_generated_event = requests_generated_event
        self.constraint_reached_event = constraint_reached_event
        self.shutdown_event = shutdown_event
        self.error_event = error_event
        self.messaging = messaging

        self._update_lock: threading.Lock = threading.Lock()
        self._state: SchedulerState = SchedulerState(
            node_id=0,
            num_processes=len(processes),
            start_time=start_time,
        )
        self._queued_request_ids: set[str] = set()
        self._pending_request_ids: set[str] = set()
        self._processing_request_ids: set[str] = set()

    def _find_request_id(self, request: RequestT) -> str:
        if hasattr(request, "request_id"):
            return str(request.request_id)
        elif hasattr(request, "id"):
            return str(request.id)
        else:
            return str(uuid.uuid4())

    def requests_generator(
        self,
        requests: DatasetIterT[RequestT],
        request_models: list[str] | None = None,
    ) -> Generator[ConversationT[RequestT], None, None]:
        """
        Generate request-info pairs for worker processing with constraint evaluation.

        Processes finite requests sequentially then cycles through repeating requests
        indefinitely. Creates scheduling metadata for each request and evaluates
        constraints to determine when to stop request generation.

        When the backend model is a comma-separated list, requests are
        round-robined across the models here — in the main process, before
        worker dispatch — so the assignment is immune to multiprocessing
        isolation (each worker would otherwise see its own backend instance).

        :param requests: Finite iterable of requests to process sequentially
        :return: Generator yielding conversation graphs for worker processing
        """

        # Round-robin model assignment for comma-separated model lists
        # (e.g. multi-LoRA adapter benchmarking). The backend's default
        # model is used when the argument is not a list.
        model_cycle = _ModelCycle(request_models or [])

        try:
            count = 0
            stop_queueing: bool = False
            yield_attempted = time.monotonic()

            for graph in requests:
                # NOTE: This must be at the start of the loop
                generation_delay = time.monotonic() - yield_attempted
                self.update_state(generation_delay=generation_delay)

                dag_state: DAGExecutionState[RequestT, ResponseT] = DAGExecutionState(
                    graph
                )
                topo_dag_nodes = dag_state.topological_order
                incoming_map: dict[str, list[str]] = {nid: [] for nid in graph.nodes}
                for edge in graph.edges:
                    incoming_map[edge.target_node_id].append(edge.source_node_id)

                for node_id in topo_dag_nodes:
                    node = graph.nodes[node_id]
                    count += 1

                    request_id = self._find_request_id(node.request)

                    # Assign the round-robin model to this request (main
                    # process, before the multiprocessing queue). Workers
                    # pick up the pre-assigned model from the request.
                    model_cycle.assign(node.request)

                    request_info: RequestInfo = RequestInfo(
                        request_id=request_id,
                        conversation_id=graph.graph_id,
                        node_id=node_id,
                        agent_id=node.agent_id,
                        parent_node_ids=incoming_map[node_id],
                        preceding_nodes=dag_state.preceding_nodes[node_id],
                        status="queued",
                        scheduler_process_id=0,
                        scheduler_start_time=self.start_time,
                        settings=node.settings,
                    )
                    state_update = self.update_state(request_info)
                    request_info.timings.queued = time.time()
                    if self.messaging.buffer_receive_queue is None:
                        raise RuntimeError("buffer receive queue is None")
                    self.messaging.buffer_receive_queue.sync_put(
                        (None, node.request, request_info, state_update.state)
                    )

                    graph.request_infos[node_id] = request_info

                    if state_update.stop_queueing:
                        stop_queueing = True
                        break

                queued_ids = set(graph.request_infos)
                to_yield = graph
                # Canceled part way through the conversation, so some nodes
                # in the DAG should not be sent.
                if queued_ids and queued_ids != set(graph.nodes):
                    to_yield = graph.subgraph_for_nodes(queued_ids)

                if to_yield.request_infos:
                    yield to_yield

                if stop_queueing:
                    self.stop_send_requests_event.set()
                    return

                # NOTE: This must be at the end of the loop
                yield_attempted = time.monotonic()

            self.update_state(
                add_constraints={
                    "requests_exhausted": RequestsExhaustedConstraint(
                        num_requests=count
                    )
                },
            )
            self.stop_send_requests_event.set()
        except Exception as err:
            logger.error("Error generating requests: {}", err)
            self.error_event.set()
            raise err

    def received_callback(
        self,
        update: tuple[
            ResponseT | None,
            RequestT,
            RequestInfo,
        ],
    ) -> tuple[
        ResponseT | None,
        RequestT,
        RequestInfo,
        SchedulerState,
    ]:
        """
        Process received request updates and inject current scheduler state.

        Updates internal state tracking based on request status changes and
        evaluates constraints to determine if processing should be terminated.
        Triggers shutdown when stop conditions are met.

        :param update: Tuple containing response, request, and request info
        :return: Updated tuple with injected scheduler state
        """
        try:
            response, request, request_info = update
            state_update = self.update_state(info=request_info)

            # Check if we need to tell workers to stop pulling new requests
            # based on no more requests sent and all requests removed from queue
            if (
                state_update.state.queued_requests == 0
                and self.stop_send_requests_event.is_set()
                and not self.requests_generated_event.is_set()
            ):
                self.requests_generated_event.set()

            # Check if we need to tell workers to stop processing requests (constraints)
            if (
                state_update.stop_processing
                and not self.constraint_reached_event.is_set()
            ):
                self.constraint_reached_event.set()

            # Check if all requests have been processed and can shutdown
            if (
                state_update.state.processed_requests
                == state_update.state.created_requests
                and self.stop_send_requests_event.is_set()
                and self.requests_generated_event.is_set()
                and self.constraint_reached_event.is_set()
                and not self.shutdown_event.is_set()
            ):
                self.shutdown_event.set()
        except Exception as err:
            logger.error("Error processing received update: {}", err)
            self.error_event.set()
            raise err

        return (
            response,
            request,
            request_info,
            state_update.state,  # inject state for updates to be yielded back
        )

    def update_state(
        self,
        info: RequestInfo | None = None,
        add_constraints: dict[str, Constraint] | None = None,
        generation_delay: float | None = None,
    ) -> _StateUpdate:
        """Update scheduler state and re-evaluate constraints.

        With no ``info``, only scheduler state is considered. The coordinator
        poll loop uses that so time-based constraints such as ``max_duration``
        can fire while workers are sleeping and no request updates arrive.

        :param info: Request that changed, or ``None`` for a state-only recheck
        :param add_constraints: Constraints to register before evaluation
        :param generation_delay: Conversation-level request-generator delay to
            record once per conversation, or ``None`` to skip
        :return: Copied scheduler state and stop flags
        """
        with self._update_lock:
            if add_constraints is not None:
                self.constraints.update(add_constraints)

            self._state.end_time = time.time()  # Always update in case last update
            if info is not None:
                self._update_state_request_counts(info)
            if generation_delay is not None:
                self._state.generation_delay_samples.append(generation_delay)

            self._update_with_constraints(info)

            state_copy: SchedulerState = self._state.model_copy()

        return _StateUpdate(
            state_copy,
            state_copy.end_queuing_time is not None,
            state_copy.end_processing_time is not None,
        )

    def _update_state_request_counts(self, info: RequestInfo):
        finalized = time.time()

        if info.status == "queued":
            self._queued_request_ids.add(info.request_id)
            self._state.queued_requests = len(self._queued_request_ids)
            self._state.created_requests += 1
        elif info.status == "pending":
            if info.request_id not in self._queued_request_ids:
                # Already finalized by a racing terminal update; ignore.
                return
            self._queued_request_ids.remove(info.request_id)
            self._state.queued_requests = len(self._queued_request_ids)
            self._pending_request_ids.add(info.request_id)
            self._state.pending_requests = len(self._pending_request_ids)
        elif info.status == "in_progress":
            if info.request_id not in self._pending_request_ids:
                # Already finalized by a racing terminal update; ignore.
                return
            self._pending_request_ids.remove(info.request_id)
            self._state.pending_requests = len(self._pending_request_ids)
            self._processing_request_ids.add(info.request_id)
            self._state.processing_requests = len(self._processing_request_ids)
        elif info.status == "first_token":
            pass
        elif info.status in ("completed", "errored", "cancelled"):
            if not self._finalize_terminal_request(info, finalized):
                # Already finalized by a racing terminal update; ignore.
                return
        else:
            raise ValueError(f"Unknown request_info status {info.status} for {info}")

        self._update_request_time_bounds(info, finalized)

    def _update_request_time_bounds(self, info: RequestInfo, finalized: float) -> None:
        # Keep global count of the earliest start and latest end
        if info.timings.request_start is not None:
            self._state.start_requests_time = min(
                info.timings.request_start,
                self._state.start_requests_time or float("inf"),
            )
        self._state.end_requests_time = max(
            info.timings.request_end or float("-inf"),
            self._state.end_requests_time or float("-inf"),
            finalized,
        )

    def _finalize_terminal_request(self, info: RequestInfo, finalized: float) -> bool:
        """
        Apply a completed/errored/cancelled update to the tracking sets.

        :return: False if the request was already finalized by a prior
            terminal update (nothing is changed in that case), True otherwise.
        """
        if info.status == "completed":
            if info.request_id not in self._processing_request_ids:
                return False
            info.timings.finalized = finalized
            self._processing_request_ids.remove(info.request_id)
            self._state.processing_requests = len(self._processing_request_ids)
            self._state.processed_requests += 1
            self._state.successful_requests += 1
            return True

        if (
            info.request_id not in self._queued_request_ids
            and info.request_id not in self._pending_request_ids
            and info.request_id not in self._processing_request_ids
        ):
            return False

        info.timings.finalized = finalized
        if info.request_id in self._queued_request_ids:
            self._queued_request_ids.remove(info.request_id)
            self._state.queued_requests = len(self._queued_request_ids)
        elif info.request_id in self._pending_request_ids:
            self._pending_request_ids.remove(info.request_id)
            self._state.pending_requests = len(self._pending_request_ids)
        elif info.request_id in self._processing_request_ids:
            self._processing_request_ids.remove(info.request_id)
            self._state.processing_requests = len(self._processing_request_ids)

        self._state.processed_requests += 1
        self._state.errored_requests += 1 if info.status == "errored" else 0
        self._state.cancelled_requests += 1 if info.status == "cancelled" else 0
        return True

    def _update_with_constraints(self, info: RequestInfo | None):
        actions: dict[str, SchedulerUpdateAction] = {
            name: const(self._state, info) for name, const in self.constraints.items()
        }
        self._state.scheduler_constraints = actions
        stop_queuing_actions = {}
        stop_processing_actions = {}

        for key, action in actions.items():
            # Action updates
            if (
                self._state.end_queuing_time is None
                and action.request_queuing == "stop"
            ):
                stop_queuing_actions[key] = action
            if (
                self._state.end_processing_time is None
                and action.request_processing in ("stop_local", "stop_all")
            ):
                stop_processing_actions[key] = action

            self._state.progress.combine(action.progress)

        if stop_queuing_actions:
            self._state.end_queuing_constraints = stop_queuing_actions
            self._state.end_queuing_time = time.time()

        if stop_processing_actions:
            self._state.end_processing_constraints = stop_processing_actions
            self._state.end_processing_time = time.time()
            if self._state.progress.stop_time is None:
                self._state.progress.stop_time = self._state.end_processing_time
