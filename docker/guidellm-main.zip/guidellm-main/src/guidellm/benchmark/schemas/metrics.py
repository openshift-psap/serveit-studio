"""
Metrics schemas for generative AI benchmark results and performance analysis.

This module defines comprehensive metric structures for tracking and analyzing
generative AI benchmark performance across multiple dimensions including request
statistics, token metrics, and domain-specific measurements for text, image, video,
and audio generation. It provides statistical summaries with distribution analysis
across successful, incomplete, and errored requests, along with scheduler-level
performance metrics for request processing and queueing behavior.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from guidellm.benchmark.schemas.accumulator import (
    GenerativeBenchmarkAccumulator,
)
from guidellm.scheduler import SchedulerState
from guidellm.schemas import (
    DistributionSummary,
    GenerativeRequestStats,
    SampleUncertainty,
    StandardBaseDict,
    StatusBreakdown,
    StatusDistributionSummary,
)
from guidellm.schemas.benchmark import GoodputSLO

__all__ = [
    "GenerativeAudioMetricsSummary",
    "GenerativeImageMetricsSummary",
    "GenerativeMetrics",
    "GenerativeMetricsSummary",
    "GenerativeTextMetricsSummary",
    "GenerativeToolCallMetricsSummary",
    "GenerativeTurnMetrics",
    "GenerativeVideoMetricsSummary",
    "SchedulerMetrics",
    "StatusTypes",
    "TimedMetricTypeAlias",
]


TimedMetricTypeAlias = (
    tuple[float, float, int | float | None, int | float | None] | None
)
"""Timed metric tuple containing start_time, end_time, input_value, and output_value."""

StatusTypes = Literal["successful", "incomplete", "errored"]
"""Request status category for metric compilation."""

# Constants for tuple indexing
_TIMED_METRIC_START_TIME_INDEX = 0
_TIMED_METRIC_END_TIME_INDEX = 1
_TIMED_METRIC_INPUT_VALUE_INDEX = 2
_TIMED_METRIC_OUTPUT_VALUE_INDEX = 3


class SchedulerMetrics(StandardBaseDict):
    """Scheduler timing and performance statistics.

    Tracks overall benchmark timing, request counts by status, and detailed internal
    scheduler performance metrics including queue times, processing delays, and
    request execution statistics. Used to analyze scheduler efficiency and identify
    bottlenecks in request processing pipelines.
    """

    # Overall timings for the scheduler
    start_time: float = Field(
        description="Unix timestamp when the benchmark run started"
    )
    request_start_time: float = Field(
        description="Unix timestamp when first request was made"
    )
    measure_start_time: float = Field(
        description="Unix timestamp when measurement period started"
    )
    measure_end_time: float = Field(
        description="Unix timestamp when measurement period ended"
    )
    request_end_time: float = Field(
        description="Unix timestamp when last request completed"
    )
    end_time: float = Field(description="Unix timestamp when the benchmark run ended")

    # Request details tracked by the scheduler
    requests_made: StatusBreakdown[int, int, int, int] = Field(
        description="Request counts by status: successful, incomplete, errored, total"
    )

    # Scheduler internal performance timings
    generation_delay: DistributionSummary = Field(
        default_factory=lambda: DistributionSummary.from_values([]),
        description=(
            "Distribution of time between attempting to yield a conversation "
            "from the request generator and actually yielding it (seconds)"
        ),
    )
    queued_time_avg: float = Field(
        description="Avg time requests spent in the queue (seconds)"
    )
    resolve_start_delay_avg: float = Field(
        description="Avg delay before worker begins resolving req after dequeue (sec)"
    )
    resolve_targeted_start_delay_avg: float = Field(
        description="Avg delay to targeted resolve start time (seconds)"
    )
    request_start_delay_avg: float = Field(
        description="Avg delay before request starts after resolve (seconds)"
    )
    request_targeted_start_delay_avg: float = Field(
        description="Avg delay to targeted request start time (seconds)"
    )
    request_time_avg: float = Field(description="Avg request execution time (seconds)")
    resolve_end_delay_avg: float = Field(
        description="Avg delay after request completes before resolve ends (seconds)"
    )
    resolve_time_avg: float = Field(
        description="Avg total resolve time including request (seconds)"
    )
    finalized_delay_avg: float = Field(
        description="Avg delay from resolve end to request finalization (seconds)"
    )
    processed_delay_avg: float = Field(
        description="Avg delay from finalization to processing completion (seconds)"
    )
    dataset_incomplete: bool = Field(
        default=False,
        description=(
            "True when the request iterator stopped before it was exhausted. "
            "False when the scheduler registered requests_exhausted"
        ),
    )
    strategy_type: str = Field(
        default="",
        description="Type identifier of the strategy that ran this benchmark",
    )

    @classmethod
    def compile(
        cls,
        accumulator: GenerativeBenchmarkAccumulator,
        scheduler_state: SchedulerState,
    ) -> SchedulerMetrics:
        """
        Compile scheduler metrics from accumulator and scheduler state.

        :param accumulator: Benchmark accumulator containing timing and metric data
        :param scheduler_state: Scheduler state with execution timing information
        :return: Compiled scheduler metrics with performance statistics
        """
        return SchedulerMetrics(
            # Overall timings for the scheduler
            start_time=scheduler_state.start_time,
            request_start_time=accumulator.timings.finalized_request_start,
            measure_start_time=accumulator.timings.finalized_measure_start,
            measure_end_time=accumulator.timings.finalized_measure_end,
            request_end_time=accumulator.timings.finalized_request_end,
            end_time=scheduler_state.end_time or -1.0,
            # Request details tracked by the scheduler
            requests_made=accumulator.scheduler_metrics.requests_made,
            # Scheduler internal performance timings
            generation_delay=DistributionSummary.from_values(
                scheduler_state.generation_delay_samples
            ),
            queued_time_avg=accumulator.scheduler_metrics.queued_time.mean or -1.0,
            resolve_start_delay_avg=(
                accumulator.scheduler_metrics.resolve_start_delay.mean or -1.0
            ),
            resolve_targeted_start_delay_avg=(
                accumulator.scheduler_metrics.resolve_targeted_start_delay.mean or -1.0
            ),
            request_start_delay_avg=(
                accumulator.scheduler_metrics.request_start_delay.mean or -1.0
            ),
            request_targeted_start_delay_avg=(
                accumulator.scheduler_metrics.request_targeted_start_delay.mean or -1.0
            ),
            request_time_avg=accumulator.scheduler_metrics.request_time.mean or -1.0,
            resolve_end_delay_avg=(
                accumulator.scheduler_metrics.resolve_end_delay.mean or -1.0
            ),
            resolve_time_avg=accumulator.scheduler_metrics.resolve_time.mean or -1.0,
            finalized_delay_avg=(
                accumulator.scheduler_metrics.finalized_delay.mean or -1.0
            ),
            processed_delay_avg=(
                accumulator.scheduler_metrics.processed_delay.mean or -1.0
            ),
            dataset_incomplete=(
                "requests_exhausted" not in scheduler_state.scheduler_constraints
            ),
            strategy_type=accumulator.config.strategy.type_,
        )


class GenerativeMetricsSummary(StandardBaseDict):
    """
    Statistical summaries for input, output, and total metrics.

    Provides distribution summaries across successful, incomplete, and errored
    requests for absolute values, per-second rates, and concurrency levels.
    """

    input: StatusDistributionSummary | None = Field(
        description="Distribution of input metric values"
    )
    input_per_second: StatusDistributionSummary | None = Field(
        description="Distribution of input metric rates per second"
    )
    input_concurrency: StatusDistributionSummary | None = Field(
        description="Distribution of concurrent input metric values"
    )

    output: StatusDistributionSummary | None = Field(
        description="Distribution of output metric values"
    )
    output_per_second: StatusDistributionSummary | None = Field(
        description="Distribution of output metric rates per second"
    )
    output_concurrency: StatusDistributionSummary | None = Field(
        description="Distribution of concurrent output metric values"
    )

    total: StatusDistributionSummary | None = Field(
        description="Distribution of total metric values (input + output)"
    )
    total_per_second: StatusDistributionSummary | None = Field(
        description="Distribution of total metric rates per second"
    )
    total_concurrency: StatusDistributionSummary | None = Field(
        description="Distribution of concurrent total metric values"
    )

    @classmethod
    def compile(
        cls,
        property_name: str,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeMetricsSummary | None:
        """
        Compile metrics summary from request statistics for a specific property.

        :param property_name: Name of the property to extract from request metrics
        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete or cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled metrics summary or None if no data available
        """
        successful_metrics = cls.extract_property_metrics_for_summary(
            successful, property_name
        )
        incomplete_metrics = cls.extract_property_metrics_for_summary(
            incomplete, property_name
        )
        errored_metrics = cls.extract_property_metrics_for_summary(
            errored, property_name
        )

        return cls.compile_timed_metrics(
            successful=successful_metrics,
            incomplete=incomplete_metrics,
            errored=errored_metrics,
        )

    @classmethod
    def compile_timed_metrics(
        cls,
        successful: list[TimedMetricTypeAlias],
        incomplete: list[TimedMetricTypeAlias],
        errored: list[TimedMetricTypeAlias],
    ) -> GenerativeMetricsSummary | None:
        """
        Compile metrics summary from timed metric tuples.

        :param successful: Timed metrics from successful requests
        :param incomplete: Timed metrics from incomplete requests
        :param errored: Timed metrics from errored requests
        :return: Compiled metrics summary or None if no data available
        """

        def _compile_metric_distributions(
            metrics_by_status: dict[StatusTypes, list[TimedMetricTypeAlias]],
            value_index: int,
        ) -> tuple[
            StatusDistributionSummary | None,
            StatusDistributionSummary | None,
            StatusDistributionSummary | None,
            dict[StatusTypes, list[float]],
            dict[StatusTypes, list[tuple[float, float]]],
            dict[StatusTypes, list[tuple[float, float, float]]],
        ]:
            """Helper to compile value, rate, and concurrency distributions."""
            # Filter out None values instead of coercing to 0.0 so we can
            # distinguish "metric not applicable" (None) from "metric is
            # zero" (e.g. errored tool call requests with tool_call_count=0).
            value_lists: dict[StatusTypes, list[float]] = {
                status: [
                    float(val)
                    for metric in metrics
                    if metric is not None
                    for val in [metric[value_index]]
                    if val is not None
                ]
                for status, metrics in metrics_by_status.items()
            }

            # No data at all for this value index — skip distributions.
            if all(len(vl) == 0 for vl in value_lists.values()):
                return None, None, None, value_lists, {}, {}

            value_dist = StatusDistributionSummary.from_values(
                successful=value_lists["successful"],
                incomplete=value_lists["incomplete"],
                errored=value_lists["errored"],
            )

            rate_lists: dict[StatusTypes, list[tuple[float, float]]] = {
                status: [
                    (  # type: ignore[misc]
                        metric[_TIMED_METRIC_END_TIME_INDEX],
                        float(val),
                    )
                    for metric in metrics
                    if metric is not None
                    for val in [metric[value_index]]
                    if val is not None
                ]
                for status, metrics in metrics_by_status.items()
            }
            rate_dist = StatusDistributionSummary.rate_distribution_from_timings(
                successful=rate_lists["successful"],
                incomplete=rate_lists["incomplete"],
                errored=rate_lists["errored"],
            )

            concurrency_lists: dict[StatusTypes, list[tuple[float, float, float]]] = {
                status: [
                    (  # type: ignore[misc]
                        metric[_TIMED_METRIC_START_TIME_INDEX],
                        metric[_TIMED_METRIC_END_TIME_INDEX],
                        float(val),
                    )
                    for metric in metrics
                    if metric is not None
                    for val in [metric[value_index]]
                    if val is not None
                ]
                for status, metrics in metrics_by_status.items()
            }
            concurrency_dist = (
                StatusDistributionSummary.concurrency_distribution_from_timings(
                    successful=concurrency_lists["successful"],
                    incomplete=concurrency_lists["incomplete"],
                    errored=concurrency_lists["errored"],
                )
            )

            return (
                value_dist,
                rate_dist,
                concurrency_dist,
                value_lists,
                rate_lists,
                concurrency_lists,
            )

        metrics_by_status: dict[StatusTypes, list[TimedMetricTypeAlias]] = {
            "successful": successful,
            "incomplete": incomplete,
            "errored": errored,
        }

        # Calculate input distributions
        (
            input_value_dist,
            input_rate_dist,
            input_concurrency_dist,
            input_value_lists,
            input_rate_lists,
            input_concurrency_lists,
        ) = _compile_metric_distributions(
            metrics_by_status, _TIMED_METRIC_INPUT_VALUE_INDEX
        )

        # Calculate output distributions
        (
            output_value_dist,
            output_rate_dist,
            output_concurrency_dist,
            output_value_lists,
            output_rate_lists,
            output_concurrency_lists,
        ) = _compile_metric_distributions(
            metrics_by_status, _TIMED_METRIC_OUTPUT_VALUE_INDEX
        )

        # Calculate total distributions if both input and output have data
        if input_value_dist is not None and output_value_dist is not None:
            total_value_dist = StatusDistributionSummary.from_values(
                successful=(
                    input_value_lists["successful"] + output_value_lists["successful"]
                ),
                incomplete=(
                    input_value_lists["incomplete"] + output_value_lists["incomplete"]
                ),
                errored=input_value_lists["errored"] + output_value_lists["errored"],
            )
            total_rate_dist = StatusDistributionSummary.rate_distribution_from_timings(
                successful=(
                    input_rate_lists["successful"] + output_rate_lists["successful"]
                ),
                incomplete=(
                    input_rate_lists["incomplete"] + output_rate_lists["incomplete"]
                ),
                errored=input_rate_lists["errored"] + output_rate_lists["errored"],
            )
            total_concurrency_dist = (
                StatusDistributionSummary.concurrency_distribution_from_timings(
                    successful=(
                        input_concurrency_lists["successful"]
                        + output_concurrency_lists["successful"]
                    ),
                    incomplete=(
                        input_concurrency_lists["incomplete"]
                        + output_concurrency_lists["incomplete"]
                    ),
                    errored=(
                        input_concurrency_lists["errored"]
                        + output_concurrency_lists["errored"]
                    ),
                )
            )
        else:
            total_value_dist = None
            total_rate_dist = None
            total_concurrency_dist = None

        return GenerativeMetricsSummary(
            input=input_value_dist,
            input_per_second=input_rate_dist,
            input_concurrency=input_concurrency_dist,
            output=output_value_dist,
            output_per_second=output_rate_dist,
            output_concurrency=output_concurrency_dist,
            total=total_value_dist,
            total_per_second=total_rate_dist,
            total_concurrency=total_concurrency_dist,
        )

    @classmethod
    def extract_property_metrics_for_summary(
        cls, stats_list: list[GenerativeRequestStats], property_name: str
    ) -> list[TimedMetricTypeAlias]:
        """
        Extract timed metrics for a specific property from request statistics.

        :param stats_list: List of request statistics to extract from
        :param property_name: Name of the property to extract from metrics
        :return: List of tuples containing
            (start_time, end_time, input_value, output_value)
        """
        return [
            (
                stats.request_start_time,
                stats.request_end_time,
                getattr(stats.input_metrics, property_name),
                getattr(stats.output_metrics, property_name),
            )
            for stats in stats_list
            if (
                stats.request_start_time
                and stats.request_end_time
                and (
                    getattr(stats.input_metrics, property_name) is not None
                    or getattr(stats.output_metrics, property_name) is not None
                )
            )
        ]


class GenerativeTextMetricsSummary(StandardBaseDict):
    """
    Text-specific metric summaries for generative benchmarks.

    Tracks token, word, and character-level metrics across input, output, and
    total usage for text generation workloads.
    """

    tokens: GenerativeMetricsSummary | None = Field(
        description="Token count metrics and distributions"
    )
    words: GenerativeMetricsSummary | None = Field(
        description="Word count metrics and distributions"
    )
    characters: GenerativeMetricsSummary | None = Field(
        description="Character count metrics and distributions"
    )

    @classmethod
    def compile(
        cls,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeTextMetricsSummary:
        """
        Compile text metrics summary from request statistics.

        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete/cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled text metrics summary
        """
        return GenerativeTextMetricsSummary(
            tokens=GenerativeMetricsSummary.compile(
                property_name="text_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            words=GenerativeMetricsSummary.compile(
                property_name="text_words",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            characters=GenerativeMetricsSummary.compile(
                property_name="text_characters",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
        )


class GenerativeImageMetricsSummary(StandardBaseDict):
    """
    Image-specific metric summaries for generative benchmarks.

    Tracks token, image count, pixel, and byte-level metrics across input, output,
    and total usage for image generation workloads.
    """

    tokens: GenerativeMetricsSummary | None = Field(
        description="Image token count metrics and distributions"
    )
    images: GenerativeMetricsSummary | None = Field(
        description="Image count metrics and distributions"
    )
    pixels: GenerativeMetricsSummary | None = Field(
        description="Pixel count metrics and distributions"
    )
    bytes: GenerativeMetricsSummary | None = Field(
        description="Byte size metrics and distributions"
    )

    @classmethod
    def compile(
        cls,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeImageMetricsSummary:
        """
        Compile image metrics summary from request statistics.

        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete/cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled image metrics summary
        """
        return GenerativeImageMetricsSummary(
            tokens=GenerativeMetricsSummary.compile(
                property_name="image_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            images=GenerativeMetricsSummary.compile(
                property_name="image_count",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            pixels=GenerativeMetricsSummary.compile(
                property_name="image_pixels",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            bytes=GenerativeMetricsSummary.compile(
                property_name="image_bytes",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
        )


class GenerativeVideoMetricsSummary(StandardBaseDict):
    """
    Video-specific metric summaries for generative benchmarks.

    Tracks token, frame count, duration, and byte-level metrics across input,
    output, and total usage for video generation workloads.
    """

    tokens: GenerativeMetricsSummary | None = Field(
        description="Video token count metrics and distributions"
    )
    frames: GenerativeMetricsSummary | None = Field(
        description="Frame count metrics and distributions"
    )
    seconds: GenerativeMetricsSummary | None = Field(
        description="Duration metrics in seconds and distributions"
    )
    bytes: GenerativeMetricsSummary | None = Field(
        description="Byte size metrics and distributions"
    )

    @classmethod
    def compile(
        cls,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeVideoMetricsSummary:
        """
        Compile video metrics summary from request statistics.

        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete/cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled video metrics summary
        """
        return GenerativeVideoMetricsSummary(
            tokens=GenerativeMetricsSummary.compile(
                property_name="video_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            frames=GenerativeMetricsSummary.compile(
                property_name="video_frames",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            seconds=GenerativeMetricsSummary.compile(
                property_name="video_seconds",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            bytes=GenerativeMetricsSummary.compile(
                property_name="video_bytes",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
        )


class GenerativeAudioMetricsSummary(StandardBaseDict):
    """
    Audio-specific metric summaries for generative benchmarks.

    Tracks token, sample count, duration, and byte-level metrics across input,
    output, and total usage for audio generation workloads.
    """

    tokens: GenerativeMetricsSummary | None = Field(
        description="Audio token count metrics and distributions"
    )
    samples: GenerativeMetricsSummary | None = Field(
        description="Sample count metrics and distributions"
    )
    seconds: GenerativeMetricsSummary | None = Field(
        description="Duration metrics in seconds and distributions"
    )
    bytes: GenerativeMetricsSummary | None = Field(
        description="Byte size metrics and distributions"
    )

    @classmethod
    def compile(
        cls,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeAudioMetricsSummary:
        """
        Compile audio metrics summary from request statistics.

        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete/cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled audio metrics summary
        """
        return GenerativeAudioMetricsSummary(
            tokens=GenerativeMetricsSummary.compile(
                property_name="audio_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            samples=GenerativeMetricsSummary.compile(
                property_name="audio_samples",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            seconds=GenerativeMetricsSummary.compile(
                property_name="audio_seconds",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            bytes=GenerativeMetricsSummary.compile(
                property_name="audio_bytes",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
        )


class GenerativeToolCallMetricsSummary(StandardBaseDict):
    """
    Tool-call-specific metric summaries for generative benchmarks.

    tokens: populated for tool-only turns (content null) where the full
    completion total is attributable to tool output. Subset of text_tokens.

    mixed_tokens: populated for mixed turns (content + tool calls) where the
    API does not split completion_tokens between natural language text and
    tool JSON. Subset of text_tokens.

    count: populated for all turns that include tool calls, regardless of
    whether content is also present.
    """

    tokens: GenerativeMetricsSummary | None = Field(
        description="Tool call token count metrics and distributions"
    )
    mixed_tokens: GenerativeMetricsSummary | None = Field(
        description="Mixed content + tool call token count metrics and distributions"
    )
    count: GenerativeMetricsSummary | None = Field(
        description="Tool call count metrics and distributions"
    )

    @classmethod
    def compile(
        cls,
        successful: list[GenerativeRequestStats],
        incomplete: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
    ) -> GenerativeToolCallMetricsSummary:
        """
        Compile tool call metrics summary from request statistics.

        :param successful: Successfully completed request statistics
        :param incomplete: Incomplete/cancelled request statistics
        :param errored: Failed request statistics
        :return: Compiled tool call metrics summary
        """
        return GenerativeToolCallMetricsSummary(
            tokens=GenerativeMetricsSummary.compile(
                property_name="tool_call_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            mixed_tokens=GenerativeMetricsSummary.compile(
                property_name="mixed_content_tool_tokens",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            count=GenerativeMetricsSummary.compile(
                property_name="tool_call_count",
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
        )


class GenerativeTurnMetrics(StandardBaseDict):
    """
    Request timing and size distributions for one turn position.

    In a multi-turn workload the same metric behaves differently at different
    positions in a conversation: later turns carry more history, so their
    prompts are longer and their first-token latency depends on how much of
    that history the server can reuse from its prefix cache. Aggregating all
    turns into one distribution hides that trend. Each instance holds the
    distributions for the requests at a single ``turn_index``.
    """

    turn_index: int = Field(
        description="Turn position these distributions cover, starting at 0"
    )
    request_totals: StatusBreakdown[int, int, int, int] = Field(
        description=(
            "Request counts at this turn position by status: successful, "
            "incomplete, errored, total"
        )
    )
    request_latency: StatusDistributionSummary = Field(
        description="Distribution of request latencies at this turn position"
    )
    prompt_token_count: StatusDistributionSummary = Field(
        description="Distribution of prompt token counts at this turn position"
    )
    time_to_first_token_ms: StatusDistributionSummary = Field(
        description="Distribution of first token latencies at this turn position"
    )
    inter_token_latency_ms: StatusDistributionSummary = Field(
        description="Distribution of inter-token latencies at this turn position"
    )

    @classmethod
    def compile_by_turn(
        cls,
        requests: tuple[
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
        ],
        first_token_requests: tuple[
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
        ],
        after_first_token_requests: tuple[
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
        ],
    ) -> list[GenerativeTurnMetrics] | None:
        """
        Compile per-turn distributions, or None for a single-turn workload.

        Each argument is a (successful, incomplete, errored) triple already
        filtered to the measurement window the same way as the corresponding
        aggregate metric, so a turn's distributions partition the aggregate
        ones exactly.

        :param requests: Requests within the measurement window, used for
            latency, counts and prompt sizes
        :param first_token_requests: Requests whose first token arrived within
            the measurement window, used for time to first token
        :param after_first_token_requests: Requests whose decoding started
            within the measurement window, used for inter-token latency
        :return: One entry per observed turn index in ascending order, or None
            when every request is at turn 0, where a per-turn breakdown would
            only repeat the aggregate metrics
        """
        # The windowed groups are normally subsets of ``requests``, but a
        # request without a start time is treated as instantaneous at a
        # different event in each group, so it can appear in one and not the
        # others. Collect indices from every group so no distribution is lost.
        turn_indices = sorted(
            {
                req.info.turn_index
                for groups in (
                    requests,
                    first_token_requests,
                    after_first_token_requests,
                )
                for group in groups
                for req in group
            }
        )
        if not turn_indices or turn_indices == [0]:
            return None

        def at_turn(
            groups: tuple[
                list[GenerativeRequestStats],
                list[GenerativeRequestStats],
                list[GenerativeRequestStats],
            ],
            turn_index: int,
        ) -> tuple[
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
            list[GenerativeRequestStats],
        ]:
            successful, incomplete, errored = (
                [req for req in group if req.info.turn_index == turn_index]
                for group in groups
            )
            return successful, incomplete, errored

        turns: list[GenerativeTurnMetrics] = []
        for turn_index in turn_indices:
            successful, incomplete, errored = at_turn(requests, turn_index)
            ttft_successful, ttft_incomplete, ttft_errored = at_turn(
                first_token_requests, turn_index
            )
            itl_successful, itl_incomplete, itl_errored = at_turn(
                after_first_token_requests, turn_index
            )
            turns.append(
                cls(
                    turn_index=turn_index,
                    request_totals=StatusBreakdown(
                        successful=len(successful),
                        incomplete=len(incomplete),
                        errored=len(errored),
                        total=len(successful) + len(incomplete) + len(errored),
                    ),
                    request_latency=StatusDistributionSummary.from_values_function(
                        function=lambda req: req.request_latency or 0.0,
                        successful=successful,
                        incomplete=incomplete,
                        errored=errored,
                    ),
                    prompt_token_count=StatusDistributionSummary.from_values_function(
                        function=lambda req: req.prompt_tokens or 0.0,
                        successful=successful,
                        incomplete=incomplete,
                        errored=errored,
                    ),
                    time_to_first_token_ms=StatusDistributionSummary.from_values_function(
                        function=lambda req: req.time_to_first_token_ms or 0.0,
                        successful=ttft_successful,
                        incomplete=ttft_incomplete,
                        errored=ttft_errored,
                    ),
                    inter_token_latency_ms=StatusDistributionSummary.from_values_function(
                        function=lambda req: (
                            req.inter_token_latency_ms or 0.0,
                            (req.output_tokens or 1.0) - 1.0,
                        ),
                        successful=itl_successful,
                        incomplete=itl_incomplete,
                        errored=itl_errored,
                    ),
                )
            )

        return turns


def root_dispatch_delay_distribution(
    requests: list[GenerativeRequestStats],
) -> DistributionSummary | None:
    """
    Dispatch delay for the first request of each conversation.

    First turns are requests with ``preceding_nodes == 0``. Later turns are
    omitted because a slow early turn moves them. ``turn_index`` is not used:
    with some history modes every turn stays at index 0. A request with no
    dispatch delay, which is the case when the profile has no arrival
    schedule, is omitted.

    :param requests: In-window requests, across every status
    :return: The first-turn delays, or None when none of them have a dispatch delay
    """
    delays = [
        delay
        for request in requests
        if request.info.preceding_nodes == 0
        and (delay := request.request_dispatch_delay) is not None
    ]
    if not delays:
        return None
    return DistributionSummary.from_values(delays)


class GenerativeMetrics(StandardBaseDict):
    """
    Comprehensive metrics for generative AI benchmarks.

    Aggregates request statistics, token metrics, timing distributions, and
    domain-specific measurements across text, image, video, and audio modalities.
    Provides detailed statistical summaries including distribution analysis for
    throughput, latency, concurrency, and resource utilization metrics across
    successful, incomplete, and errored requests.
    """

    # Request stats
    request_totals: StatusBreakdown[int, int, int, int] = Field(
        description="Request counts by status: successful, incomplete, errored, total"
    )
    requests_per_second: StatusDistributionSummary = Field(
        description="Distribution of requests per second across benchmark execution"
    )
    request_concurrency: StatusDistributionSummary = Field(
        description="Distribution of concurrent request counts during execution"
    )
    request_latency: StatusDistributionSummary = Field(
        description="Distribution of request latencies for completed requests"
    )
    request_dispatch_delay: StatusDistributionSummary | None = Field(
        default=None,
        description=(
            "Distribution of delays between a request's targeted start and the "
            "time it was dispatched. Grows when the scheduler cannot keep up "
            "with the configured rate. None when the strategy does not define "
            "an arrival schedule"
        ),
    )
    request_scheduled_latency: StatusDistributionSummary | None = Field(
        default=None,
        description=(
            "Distribution of request latencies measured from each request's "
            "targeted start rather than its dispatch, including scheduler "
            "delay. None when the strategy does not define an arrival "
            "schedule"
        ),
    )
    turn_predecessor_delay: StatusDistributionSummary | None = Field(
        default=None,
        description=(
            "Portion of dispatch delay spent waiting on a predecessor that "
            "was still running past the targeted start. Zero for requests "
            "with no predecessor. None when the strategy does not define an "
            "arrival schedule"
        ),
    )
    turn_scheduling_delay: StatusDistributionSummary | None = Field(
        default=None,
        description=(
            "Portion of dispatch delay after the predecessor had finished, "
            "including deserializer, queue, and worker lag. None when the "
            "strategy does not define an arrival schedule"
        ),
    )
    root_dispatch_delay: DistributionSummary | None = Field(
        default=None,
        description=(
            "Dispatch delay for the first request of each conversation. "
            "Later turns are omitted. None when no first turn has a dispatch delay"
        ),
    )
    request_streaming_iterations_count: StatusDistributionSummary = Field(
        description="Distribution of stream iterations for completed requests"
    )

    # General token stats
    prompt_token_count: StatusDistributionSummary = Field(
        description="Distribution of prompt token counts by request status"
    )
    output_token_count: StatusDistributionSummary = Field(
        description="Distribution of output token counts by request status"
    )
    total_token_count: StatusDistributionSummary = Field(
        description="Distribution of total token counts by request status"
    )
    time_to_first_token_ms: StatusDistributionSummary = Field(
        description="Distribution of first token latencies in milliseconds"
    )
    time_to_first_output_token_ms: StatusDistributionSummary = Field(
        description=(
            "Distribution of first content (non-reasoning) token latencies "
            "in milliseconds"
        )
    )
    time_per_output_token_ms: StatusDistributionSummary = Field(
        description="Distribution of average time per output token in milliseconds"
    )
    inter_token_latency_ms: StatusDistributionSummary = Field(
        description="Distribution of inter-token latencies in milliseconds"
    )
    time_to_last_round_trip_ms: StatusDistributionSummary = Field(
        description=(
            "Distribution of websocket last-round-trip latencies in milliseconds "
            "(last received token minus last sent packet)"
        )
    )
    avg_round_trip_time_ms: StatusDistributionSummary = Field(
        description=(
            "Distribution of approximate websocket average round-trip times in "
            "milliseconds (mean received minus mean sent)"
        )
    )
    prompt_tokens_per_second: StatusDistributionSummary = Field(
        description="Distribution of prompt token processing rates"
    )
    output_tokens_per_second: StatusDistributionSummary = Field(
        description="Distribution of output token generation rates"
    )
    tokens_per_second: StatusDistributionSummary = Field(
        description="Distribution of total token throughput including prompt and output"
    )
    output_tokens_per_iteration: StatusDistributionSummary = Field(
        description="Distribution of output tokens generated per streaming iteration"
    )
    iter_tokens_per_iteration: StatusDistributionSummary = Field(
        description=(
            "Distribution of output tokens (without first) generated per "
            "streaming iteration"
        )
    )

    # Domain specific stats
    text: GenerativeTextMetricsSummary = Field(
        description="Text-specific metrics for tokens, words, and characters"
    )
    image: GenerativeImageMetricsSummary = Field(
        description="Image-specific metrics for tokens, images, pixels, and bytes"
    )
    video: GenerativeVideoMetricsSummary = Field(
        description="Video-specific metrics for tokens, frames, duration, and bytes"
    )
    audio: GenerativeAudioMetricsSummary = Field(
        description="Audio-specific metrics for tokens, samples, duration, and bytes"
    )
    tool_call: GenerativeToolCallMetricsSummary = Field(
        description="Tool call metrics for tokens and call counts"
    )

    # Multi-turn stats, populated only when requests span more than one turn
    turns: list[GenerativeTurnMetrics] | None = Field(
        default=None,
        description=(
            "Per-turn-position distributions for multi-turn workloads, one "
            "entry per observed turn index in ascending order. None when every "
            "request is at turn 0"
        ),
    )

    # Goodput stats, populated only when latency objectives are configured
    slo_attainment: float | None = Field(
        default=None,
        description=(
            "Fraction of requests meeting every configured latency objective, "
            "between 0.0 and 1.0. Errored requests count as non-conforming. "
            "Requests cancelled at the measurement boundary, and requests whose "
            "objectives cannot be evaluated, are excluded from both numerator "
            "and denominator. None when no objectives are configured"
        ),
    )
    slo_determined_requests: int = Field(
        default=0,
        description=(
            "Number of requests slo_attainment is averaged over: successful "
            "requests whose objectives could all be evaluated, plus errored "
            "requests, which count as non-conforming"
        ),
    )
    request_goodput: StatusDistributionSummary | None = Field(
        default=None,
        description=(
            "Distribution of objective-conforming requests per second, computed "
            "over the same measurement window as requests_per_second so the two "
            "are directly comparable. None when no objectives are configured"
        ),
    )

    @classmethod
    def _compile_goodput(
        cls,
        slo: GoodputSLO | None,
        successful: list[GenerativeRequestStats],
        errored: list[GenerativeRequestStats],
        start_time: float,
        end_time: float,
    ) -> tuple[float | None, int, StatusDistributionSummary | None]:
        """
        Compile goodput attainment and rate against configured latency objectives.

        Errored requests count against attainment. A request that failed did not
        deliver a response within its latency objective, and on a saturated
        server overload usually surfaces as timeouts and errors rather than as
        slow successes; scoring only successful requests would report a level
        that is mostly failing as fully conforming. Incomplete requests are
        excluded instead, because they were cancelled at the measurement
        boundary by the run's own duration limit rather than by the server.

        Attainment is a ratio over the measured request population and so is not
        affected by how much of the measurement window the server spent filling
        its pipeline. The rate shares the window convention of
        ``requests_per_second`` and therefore shares its sensitivity to that
        ramp, which is why callers comparing load levels should prefer
        attainment.

        :param slo: Configured latency objectives, or None to skip goodput
        :param successful: Successful request statistics within the window
        :param errored: Errored request statistics within the window
        :param start_time: Measurement window start timestamp
        :param end_time: Measurement window end timestamp
        :return: Tuple of (attainment ratio, determined request count,
            conforming request rate). The ratio and rate are None when no
            objectives are configured or none could be evaluated
        """
        if slo is None:
            return None, 0, None

        conforming: list[GenerativeRequestStats] = []
        determined = 0
        for stats in successful:
            verdict = slo.is_conforming(
                ttft_ms=stats.time_to_first_token_ms,
                tpot_ms=stats.inter_token_latency_ms,
                e2el_ms=(
                    stats.request_latency * 1000.0
                    if stats.request_latency is not None
                    else None
                ),
            )
            if verdict is None:
                continue
            determined += 1
            if verdict:
                conforming.append(stats)

        # An errored request produced no conforming response, so it lowers
        # attainment without needing its latencies to be measurable.
        determined += len(errored)

        if determined == 0:
            # Every request lacked a measurement for at least one objective, so
            # there is no population to average over. Reporting 0.0 here would
            # read as "nothing met the objectives" rather than "the objectives
            # do not apply to this workload".
            return None, 0, None

        goodput = StatusDistributionSummary.rate_distribution_from_timings_function(
            function=lambda req: req.request_end_time,
            successful=conforming,
            incomplete=[],
            errored=[],
            start_time=start_time,
            end_time=end_time,
        )

        return len(conforming) / determined, determined, goodput

    @classmethod
    def compile(cls, accumulator: GenerativeBenchmarkAccumulator) -> GenerativeMetrics:
        """
        Compile comprehensive generative metrics from benchmark accumulator.

        :param accumulator: Benchmark accumulator with completed request statistics
        :return: Compiled generative metrics with all distributions and summaries
        :raises ValueError: If measure_start and measure_end/request_end are not set
        """
        start_time = accumulator.timings.finalized_measure_start
        end_time = accumulator.timings.finalized_measure_end

        if start_time == -1.0 or end_time == -1.0:
            raise ValueError(
                "Cannot compile GenerativeMetrics: "
                "No measurement start or end times available."
            )

        successful = accumulator.completed.get_within_range(start_time, end_time)
        incomplete = accumulator.incomplete.get_within_range(start_time, end_time)
        errored = accumulator.errored.get_within_range(start_time, end_time)

        # Intervals are reported only for metrics recorded once per request, so
        # that each value is one observation. Token-weighted metrics and derived
        # rate distributions are left without them; see docs/en/guides/metrics.md.
        uncertainty = (
            None
            if accumulator.config.confidence is None
            else SampleUncertainty(confidence=accumulator.config.confidence)
        )

        # Schedule-relative metrics describe lag against an arrival schedule.
        # Closed-loop strategies derive each target from the system's own
        # responses, so a delay measured against them is circular rather than a
        # coordinated-omission correction, and is reported as None instead.
        dispatch_delay: StatusDistributionSummary | None = None
        scheduled_latency: StatusDistributionSummary | None = None
        predecessor_delay: StatusDistributionSummary | None = None
        scheduling_delay: StatusDistributionSummary | None = None
        if accumulator.config.strategy.defines_arrival_schedule:
            dispatch_delay = StatusDistributionSummary.from_values_function(
                function=lambda req: req.request_dispatch_delay,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            )
            scheduled_latency = StatusDistributionSummary.from_values_function(
                function=lambda req: req.request_scheduled_latency,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            )
            predecessor_delay = StatusDistributionSummary.from_values_function(
                function=lambda req: req.turn_predecessor_delay,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            )
            scheduling_delay = StatusDistributionSummary.from_values_function(
                function=lambda req: req.turn_scheduling_delay,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            )

        # First-token and inter-token latencies are windowed by when the first
        # token arrived rather than by request end. Filter once so the
        # aggregate and per-turn distributions cover the same requests.
        first_token_requests = (
            accumulator.completed.get_within_range(
                start_time, end_time, end_func=lambda req: req.first_token_iteration
            ),
            accumulator.incomplete.get_within_range(
                start_time, end_time, end_func=lambda req: req.first_token_iteration
            ),
            accumulator.errored.get_within_range(
                start_time, end_time, end_func=lambda req: req.first_token_iteration
            ),
        )
        after_first_token_requests = (
            accumulator.completed.get_within_range(
                start_time, end_time, start_func=lambda req: req.first_token_iteration
            ),
            accumulator.incomplete.get_within_range(
                start_time, end_time, start_func=lambda req: req.first_token_iteration
            ),
            accumulator.errored.get_within_range(
                start_time, end_time, start_func=lambda req: req.first_token_iteration
            ),
        )

        slo_attainment, slo_determined, request_goodput = cls._compile_goodput(
            slo=accumulator.config.slo,
            successful=successful,
            errored=errored,
            start_time=start_time,
            end_time=end_time,
        )

        return GenerativeMetrics(
            slo_attainment=slo_attainment,
            slo_determined_requests=slo_determined,
            request_goodput=request_goodput,
            # Request stats
            request_totals=StatusBreakdown(
                successful=len(successful),
                incomplete=len(incomplete),
                errored=len(errored),
                total=(len(successful) + len(incomplete) + len(errored)),
            ),
            requests_per_second=StatusDistributionSummary.rate_distribution_from_timings_function(
                function=lambda req: req.request_end_time,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                start_time=start_time,
                end_time=end_time,
            ),
            request_concurrency=StatusDistributionSummary.concurrency_distribution_from_timings_function(
                function=(
                    lambda req: (
                        (req.request_start_time, req.request_end_time)
                        if req.request_start_time is not None
                        and req.request_end_time is not None
                        else None
                    )
                ),
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                start_time=start_time,
                end_time=end_time,
            ),
            request_latency=StatusDistributionSummary.from_values_function(
                function=lambda req: req.request_latency or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            request_dispatch_delay=dispatch_delay,
            request_scheduled_latency=scheduled_latency,
            turn_predecessor_delay=predecessor_delay,
            turn_scheduling_delay=scheduling_delay,
            root_dispatch_delay=root_dispatch_delay_distribution(
                [*successful, *incomplete, *errored],
            ),
            request_streaming_iterations_count=StatusDistributionSummary.from_values_function(
                function=lambda req: req.info.timings.request_iterations or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            # General token stats
            prompt_token_count=StatusDistributionSummary.from_values_function(
                function=lambda req: req.prompt_tokens or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            output_token_count=StatusDistributionSummary.from_values_function(
                function=lambda req: req.output_tokens or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            total_token_count=StatusDistributionSummary.from_values_function(
                function=lambda req: req.total_tokens or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            # TODO: Need to evaluate closed=False vs closed=True for first-token
            # latencies. See github.com/vllm-project/guidellm/issues/1078
            time_to_first_token_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: req.time_to_first_token_ms or 0.0,
                successful=first_token_requests[0],
                incomplete=first_token_requests[1],
                errored=first_token_requests[2],
                uncertainty=uncertainty,
            ),
            time_to_last_round_trip_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: req.time_to_last_round_trip_ms or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            avg_round_trip_time_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: req.avg_round_trip_time_ms or 0.0,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                uncertainty=uncertainty,
            ),
            time_to_first_output_token_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: req.time_to_first_output_token_ms or 0.0,
                successful=accumulator.completed.get_within_range(
                    start_time,
                    end_time,
                    end_func=lambda req: req.first_output_token_iteration,
                ),
                incomplete=accumulator.incomplete.get_within_range(
                    start_time,
                    end_time,
                    end_func=lambda req: req.first_output_token_iteration,
                ),
                errored=accumulator.errored.get_within_range(
                    start_time,
                    end_time,
                    end_func=lambda req: req.first_output_token_iteration,
                ),
                uncertainty=uncertainty,
            ),
            time_per_output_token_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: (
                    req.time_per_output_token_ms or 0.0,
                    req.output_tokens or 0.0,
                ),
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            inter_token_latency_ms=StatusDistributionSummary.from_values_function(
                function=lambda req: (
                    req.inter_token_latency_ms or 0.0,
                    (req.output_tokens or 1.0) - 1.0,
                ),
                successful=after_first_token_requests[0],
                incomplete=after_first_token_requests[1],
                errored=after_first_token_requests[2],
            ),
            prompt_tokens_per_second=StatusDistributionSummary.rate_distribution_from_timings_function(
                function=lambda req: req.prompt_tokens_timing,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                start_time=start_time,
                end_time=end_time,
            ),
            output_tokens_per_second=StatusDistributionSummary.rate_distribution_from_timings_function(
                function=lambda req: req.output_tokens_timings,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                start_time=start_time,
                end_time=end_time,
            ),
            tokens_per_second=StatusDistributionSummary.rate_distribution_from_timings_function(
                function=lambda req: req.total_tokens_timings,
                successful=successful,
                incomplete=incomplete,
                errored=errored,
                start_time=start_time,
                end_time=end_time,
            ),
            output_tokens_per_iteration=StatusDistributionSummary.from_values_function(
                function=lambda req: [
                    tokens for (_timing, tokens) in req.output_tokens_timings
                ],
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            iter_tokens_per_iteration=StatusDistributionSummary.from_values_function(
                function=lambda req: [
                    tokens for (_timing, tokens) in req.iter_tokens_timings
                ],
                successful=successful,
                incomplete=incomplete,
                errored=errored,
            ),
            # Domain-specific stats
            text=GenerativeTextMetricsSummary.compile(
                successful=successful, incomplete=incomplete, errored=errored
            ),
            image=GenerativeImageMetricsSummary.compile(
                successful=successful, incomplete=incomplete, errored=errored
            ),
            video=GenerativeVideoMetricsSummary.compile(
                successful=successful, incomplete=incomplete, errored=errored
            ),
            audio=GenerativeAudioMetricsSummary.compile(
                successful=successful, incomplete=incomplete, errored=errored
            ),
            tool_call=GenerativeToolCallMetricsSummary.compile(
                successful=successful, incomplete=incomplete, errored=errored
            ),
            # Multi-turn stats
            turns=GenerativeTurnMetrics.compile_by_turn(
                requests=(successful, incomplete, errored),
                first_token_requests=first_token_requests,
                after_first_token_requests=after_first_token_requests,
            ),
        )
