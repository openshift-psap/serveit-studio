from __future__ import annotations

import asyncio
import contextlib
import inspect
import multiprocessing as mp
import random
import time
from dataclasses import dataclass
from multiprocessing import Barrier, Event, Process
from multiprocessing.synchronize import Barrier as ProcessingBarrier
from multiprocessing.synchronize import Event as ProcessingEvent
from typing import Any, Generic, Literal

import pytest
import pytest_asyncio

from guidellm import configure_logger, logger
from guidellm.scheduler import (
    BackendInterface,
    SynchronousStrategy,
    WorkerProcess,
)
from guidellm.scheduler.dag import DAGExecutionState
from guidellm.scheduler.schemas import (
    ConversationEdge,
    ConversationGraph,
    ConversationNode,
)
from guidellm.schemas import RequestInfo, RequestSettings, RequestTimings
from guidellm.settings import LoggingSettings
from guidellm.utils.messaging import InterProcessMessagingQueue
from guidellm.utils.pipe_stdout import PipeReaderThread
from tests.unit.testing_utils import async_timeout, wait_until

STANDARD_NUM_REQUESTS: int = 200


@dataclass
class TimingsBounds:
    exact: float | None = None
    lower: float | None = None
    upper: float | None = None
    prev_request: Literal["greater", "greater_equal", "less", "less_equal"] | None = (
        None
    )
    tolerance: float = 10e-4
    actual_tolerance: float = 10e-4


class MockRequestTimings(RequestTimings):
    """Mock timing implementation for testing."""


class MockBackend(BackendInterface):
    """Mock backend for testing worker functionality."""

    def __init__(
        self,
        lifecycle_delay: float = 0.1,
        resolve_delay: float = 0.0,
        should_fail: bool = False,
        request_error_rate: float = 0.0,
    ):
        self.lifecycle_delay = lifecycle_delay
        self.resolve_delay = resolve_delay
        self.should_fail = should_fail
        self.request_error_rate = request_error_rate
        self.process_startup_called = False
        self.validate_called = False
        self.process_shutdown_called = False
        self.resolve_called = False

    @property
    def processes_limit(self) -> int | None:
        return None

    @property
    def requests_limit(self) -> int | None:
        return None

    @property
    def info(self) -> dict[str, Any]:
        return {
            "type": "mock",
            "lifecycle_delay": self.lifecycle_delay,
            "resolve_delay": self.resolve_delay,
        }

    async def process_startup(self):
        await asyncio.sleep(self.lifecycle_delay)
        self.process_startup_called = True

    async def validate(self):
        await asyncio.sleep(self.lifecycle_delay)
        self.validate_called = True
        if self.should_fail:
            raise RuntimeError("Mock validation failed")

    async def process_shutdown(self):
        await asyncio.sleep(self.lifecycle_delay)
        self.process_shutdown_called = True

    async def resolve(self, request, request_info, request_history):
        self.resolve_called = True
        await asyncio.sleep(
            self.resolve_delay if not str(request).startswith("cancel") else 1000.0
        )
        if self.should_fail:
            raise RuntimeError("Mock resolve failed")
        if self.request_error_rate > 0.0 and random.random() < self.request_error_rate:
            raise RuntimeError("Mock resolve failed")
        yield f"response_for_{request}", request_info


class TestWorkerProcess:
    """Test suite for WorkerProcess class."""

    @pytest_asyncio.fixture(
        params=[
            {
                "messaging": {
                    "serialization": "dict",
                    "encoding": None,
                    "max_buffer_receive_size": 2,
                },
                "worker": {
                    "async_limit": 1,
                },
            },
            {
                "messaging": {
                    "serialization": "dict",
                    "encoding": None,
                    "max_buffer_receive_size": 100,
                },
                "worker": {
                    "async_limit": 1000,
                },
            },
        ],
    )
    async def valid_instances(self, request):
        """Fixture providing test data for WorkerProcess."""
        constructor_args = request.param
        main_messaging = InterProcessMessagingQueue(
            **constructor_args["messaging"], poll_interval=0.01
        )

        await main_messaging.start(pydantic_models=[])
        try:
            instance = WorkerProcess(
                worker_index=0,
                messaging=main_messaging.create_worker_copy(0),
                backend=MockBackend(),
                strategy=SynchronousStrategy(),
                fut_scheduling_time_limit=10.0,
                **constructor_args["worker"],
                startup_barrier=Barrier(2),
                requests_generated_event=Event(),
                constraint_reached_event=Event(),
                shutdown_event=Event(),
                error_event=Event(),
                stdout_conn=None,
                stderr_conn=None,
                parent_logger=None,
            )
            yield instance, main_messaging, constructor_args
        finally:
            await main_messaging.stop()

    @pytest.mark.smoke
    def test_class_signatures(
        self,
        valid_instances: tuple[WorkerProcess, InterProcessMessagingQueue, dict],
    ):
        """Test inheritance and type relationships."""
        worker_process, main_messaging, constructor_args = valid_instances

        # Class
        assert isinstance(worker_process, Generic)
        assert issubclass(WorkerProcess, Generic)

        # Generics
        orig_bases = getattr(WorkerProcess, "__orig_bases__", ())
        assert len(orig_bases) > 0
        generic_base = next(
            (
                base
                for base in orig_bases
                if hasattr(base, "__origin__") and base.__origin__ is Generic
            ),
            None,
        )
        assert generic_base is not None
        type_args = getattr(generic_base, "__args__", ())
        assert len(type_args) == 2  # RequestT, ResponseT

        # Function signatures
        run_sig = inspect.signature(WorkerProcess.run)
        assert len(run_sig.parameters) == 1
        assert "self" in run_sig.parameters

        run_async_sig = inspect.signature(WorkerProcess.run_async)
        assert len(run_async_sig.parameters) == 1
        assert "self" in run_async_sig.parameters

        stop_processing_sig = inspect.signature(WorkerProcess._stop_monitor)
        assert len(stop_processing_sig.parameters) == 1
        assert "self" in stop_processing_sig.parameters

        requests_processing_sig = inspect.signature(WorkerProcess._process_requests)
        assert len(requests_processing_sig.parameters) == 1
        assert "self" in requests_processing_sig.parameters

    @pytest.mark.smoke
    def test_initialization(
        self,
        valid_instances: tuple[WorkerProcess, InterProcessMessagingQueue, dict],
    ):
        """Test basic initialization of WorkerProcess."""
        instance, main_messaging, constructor_args = valid_instances

        # messaging
        assert instance.messaging is not None
        assert isinstance(instance.messaging, InterProcessMessagingQueue)
        assert instance.messaging is not main_messaging
        assert instance.messaging.worker_index is not None
        assert instance.messaging.worker_index == 0
        assert (
            instance.messaging.serialization
            == constructor_args["messaging"]["serialization"]
        )
        assert instance.messaging.encoding == constructor_args["messaging"]["encoding"]
        assert (
            instance.messaging.max_buffer_receive_size
            == constructor_args["messaging"]["max_buffer_receive_size"]
        )

        # worker
        assert instance.async_limit == constructor_args["worker"]["async_limit"]
        assert instance.startup_barrier is not None
        assert isinstance(instance.startup_barrier, ProcessingBarrier)
        assert instance.shutdown_event is not None
        assert isinstance(instance.shutdown_event, ProcessingEvent)
        assert instance.error_event is not None
        assert isinstance(instance.error_event, ProcessingEvent)
        assert instance.requests_generated_event is not None
        assert isinstance(instance.requests_generated_event, ProcessingEvent)
        assert instance.constraint_reached_event is not None
        assert isinstance(instance.constraint_reached_event, ProcessingEvent)
        assert instance.backend is not None
        assert isinstance(instance.backend, MockBackend)
        assert not instance.startup_completed

    @pytest.mark.sanity
    def test_invalid_initialization(self):
        """Test that invalid initialization raises appropriate errors."""

        # Test with missing required parameters
        with pytest.raises(TypeError):
            WorkerProcess()

        # Create a complete set of valid parameters
        backend = MockBackend()
        barrier = Barrier(2)
        shutdown_event = Event()
        error_event = Event()
        requests_generated_event = Event()
        constraint_reached_event = Event()
        messaging = InterProcessMessagingQueue()

        # Test missing each required parameter one by one
        required_params = [
            "messaging",
            "backend",
            "async_limit",
            "startup_barrier",
            "requests_generated_event",
            "constraint_reached_event",
            "shutdown_event",
            "error_event",
            "stdout_conn",
            "stderr_conn",
            "parent_logger",
        ]

        for param_to_remove in required_params:
            kwargs = {
                "messaging": messaging,
                "backend": backend,
                "async_limit": 5,
                "startup_barrier": barrier,
                "requests_generated_event": requests_generated_event,
                "constraint_reached_event": constraint_reached_event,
                "shutdown_event": shutdown_event,
                "error_event": error_event,
                "stdout_conn": None,
                "stderr_conn": None,
                "parent_logger": None,
            }

            del kwargs[param_to_remove]

            with pytest.raises(TypeError):
                WorkerProcess(**kwargs)

    @pytest.mark.xfail(reason="old and broken", run=False)
    @pytest.mark.smoke
    @pytest.mark.asyncio
    @async_timeout(15)
    @pytest.mark.parametrize(
        ("num_requests", "num_canceled", "error_rate"),
        [
            (20, 0, 0),
            (STANDARD_NUM_REQUESTS, 20, 0.5),
        ],
    )
    async def test_run_async_lifecycle(  # noqa: C901, PLR0912
        self,
        valid_instances: tuple[WorkerProcess, InterProcessMessagingQueue, dict],
        num_requests: int,
        num_canceled: int,
        error_rate: float,
    ):
        """Test the asynchronous request processing of WorkerProcess."""
        instance, main_messaging, constructor_args = valid_instances
        instance.backend.request_error_rate = error_rate
        instance_task = asyncio.create_task(instance.run_async())

        try:
            await asyncio.to_thread(instance.startup_barrier.wait)
            start_time = time.time()

            # Send regular requests
            requests_tracker = {}
            for index in range(num_requests):
                request = f"request_{index}"
                request_info = RequestInfo(
                    request_id=request,
                    scheduler_start_time=start_time,
                    scheduler_process_id=0,
                )
                request_info.scheduler_timings.queued = time.time()
                requests_tracker[request] = {
                    "sent": True,
                    "received_pending": 0,
                    "received_in_progress": 0,
                    "received_resolved": 0,
                }
                await main_messaging.put(
                    (request, request_info),
                    timeout=2.0,
                )

            # Process regular requests
            error_count = 0
            for _ in range(num_requests * 3):
                # Each request must have a pending, in_progress, and resolution
                response, request, request_info = await main_messaging.get(timeout=2.0)
                assert request is not None
                assert request_info is not None
                assert request_info.request_id is not None
                assert request_info.status is not None
                assert request_info.scheduler_node_id > -1
                assert request_info.scheduler_process_id > -1
                assert request_info.scheduler_start_time == start_time
                assert request_info.scheduler_timings is not None
                assert request_info.scheduler_timings.targeted_start is not None
                assert request_info.scheduler_timings.targeted_start >= start_time

                if request_info.status == "pending":
                    requests_tracker[request]["received_pending"] += 1
                    assert request_info.scheduler_timings.dequeued is not None
                    assert (
                        request_info.scheduler_timings.dequeued
                        >= request_info.scheduler_timings.targeted_start
                    )
                elif request_info.status == "in_progress":
                    requests_tracker[request]["received_in_progress"] += 1
                    assert request_info.scheduler_timings.scheduled_at is not None
                    assert (
                        request_info.scheduler_timings.scheduled_at
                        >= request_info.scheduler_timings.dequeued
                    )
                    assert request_info.scheduler_timings.resolve_start is not None
                    assert (
                        request_info.scheduler_timings.resolve_start
                        >= request_info.scheduler_timings.scheduled_at
                    )
                elif request_info.status == "completed":
                    assert response == f"response_for_{request}"
                    requests_tracker[request]["received_resolved"] += 1
                    assert request_info.scheduler_timings.resolve_end is not None
                    assert (
                        request_info.scheduler_timings.resolve_end
                        > request_info.scheduler_timings.resolve_start
                    )
                elif request_info.status == "errored":
                    assert response is None
                    requests_tracker[request]["received_resolved"] += 1
                    error_count += 1
                    assert request_info.scheduler_timings.resolve_end is not None
                    assert (
                        request_info.scheduler_timings.resolve_end
                        > request_info.scheduler_timings.resolve_start
                    )
                else:
                    raise ValueError(f"Unexpected status: {request_info.status}")

            # Ensure correct error rate
            assert float(error_count) / num_requests == pytest.approx(
                error_rate, rel=0.2
            )

            # Ensure no extra statuses
            with pytest.raises(asyncio.TimeoutError):
                await main_messaging.get(timeout=0.5)

            # Send cancel requests
            for index in range(num_canceled):
                cancel_request = f"cancel_request_{index}"
                cancel_info = RequestInfo(
                    request_id=request,
                    scheduler_start_time=start_time,
                    scheduler_process_id=0,
                )
                cancel_info.scheduler_timings.queued = time.time()
                requests_tracker[cancel_request] = {
                    "sent": True,
                    "received_pending": 0,
                    "received_in_progress": 0,
                    "received_resolved": 0,
                }
                await main_messaging.put(
                    (cancel_request, cancel_info),
                    timeout=2.0,
                )

            # Receive expected updates for cancel up to async number
            for _ in range(2 * min(num_canceled, instance.async_limit)):
                # Each request (up to async limit) will have pending, in_progress
                response, request, request_info = await main_messaging.get(timeout=2.0)
                if request_info.status == "pending":
                    requests_tracker[request]["received_pending"] += 1
                elif request_info.status == "in_progress":
                    requests_tracker[request]["received_in_progress"] += 1
                    error_count += 1
                else:
                    raise ValueError(f"Unexpected status: {request_info.status}")

            # Signal constraints reached to start canceling
            instance.constraint_reached_event.set()
            await asyncio.sleep(0)

            # Receive the remaining canceled updates
            for _ in range(num_canceled):
                # All cancel requests should resolve with canceled (no other statuses)
                response, request, request_info = await main_messaging.get(timeout=2.0)
                assert request is not None
                assert request_info is not None
                assert request_info.request_id is not None
                assert request_info.status is not None
                assert request_info.scheduler_node_id > -1
                assert request_info.scheduler_process_id > -1
                assert request_info.scheduler_start_time == start_time
                assert request_info.scheduler_timings is not None

                if request_info.status == "cancelled":
                    requests_tracker[request]["received_resolved"] += 1
                    assert request_info.scheduler_timings.resolve_end is not None
                    assert request_info.scheduler_timings.resolve_end > start_time
                else:
                    raise ValueError(f"Unexpected status: {request_info.status}")

            # Ensure no extra statuses
            with pytest.raises(asyncio.TimeoutError):
                await main_messaging.get(timeout=0.5)

            # Signal requests stop now that all requests have been processed
            instance.requests_generated_event.set()
            await asyncio.sleep(0)

            # Validate all the requests are correct
            for request_key in [f"request_{index}" for index in range(num_requests)]:
                assert request_key in requests_tracker
                assert requests_tracker[request_key]["sent"]
                assert requests_tracker[request_key]["received_pending"] == 1
                assert requests_tracker[request_key]["received_resolved"] == 1
                if request_key.startswith("request"):
                    assert requests_tracker[request_key]["received_in_progress"] == 1
        finally:
            # Shut down
            instance.shutdown_event.set()
            await asyncio.wait_for(instance_task, timeout=2.0)

    @pytest.mark.xfail(reason="old and broken", run=False)
    @pytest.mark.smoke
    @pytest.mark.asyncio
    @async_timeout(15)
    @pytest.mark.parametrize(
        ("request_timings", "timing_bounds"),
        [
            (
                RequestTimings(offset=0.1),
                [
                    TimingsBounds(lower=0.1, prev_request="greater_equal")
                    for _ in range(STANDARD_NUM_REQUESTS)
                ],
            ),
            (
                RequestTimings(offset=0.05),
                [
                    TimingsBounds(lower=0.05, upper=0.05, actual_tolerance=1.0)
                    for _ in range(STANDARD_NUM_REQUESTS)
                ],
            ),
            (
                RequestTimings(rate=100, offset=0.2),
                [
                    TimingsBounds(
                        exact=0.2 + ind * 0.01,
                        lower=0.2,
                        prev_request="greater",
                        actual_tolerance=10e-2,
                    )
                    for ind in range(STANDARD_NUM_REQUESTS)
                ],
            ),
            (
                RequestTimings(rate=200, offset=0.01),
                [
                    TimingsBounds(lower=0.01, prev_request="greater")
                    for ind in range(STANDARD_NUM_REQUESTS)
                ],
            ),
        ],
        ids=[
            "LastCompletion",
            "NoDelay",
            "ConstantRate",
            "PoissonRate",
        ],
    )
    async def test_run_with_timings(  # noqa: C901, PLR0912
        self,
        valid_instances: tuple[WorkerProcess, InterProcessMessagingQueue, dict],
        request_timings: RequestTimings,
        timing_bounds: list[TimingsBounds],
    ):
        instance, main_messaging, constructor_args = valid_instances
        num_requests = STANDARD_NUM_REQUESTS
        assert len(timing_bounds) == num_requests

        # Start process
        process = Process(target=instance.run)
        process.start()

        try:
            await asyncio.to_thread(instance.startup_barrier.wait)
            start_time = time.time() + 0.1

            # Send regular requests
            requests_tracker = {}
            for ind in range(num_requests):
                request = f"request_{ind}"
                requests_tracker[request] = {
                    "sent": True,
                    "target_start_time": -1,
                    "actual_start_time": -1,
                    "received_pending": 0,
                    "received_in_progress": 0,
                    "received_resolved": 0,
                }
                await main_messaging.put(
                    (
                        request,
                        RequestInfo(scheduler_start_time=start_time),
                    ),
                    timeout=2.0,
                )

            # Process regular requests
            for _ in range(num_requests * 3):
                # Each request must have pending, in_progress, and resolved statuses
                response, request, request_info = await main_messaging.get(timeout=2.0)
                if request_info.status == "pending":
                    requests_tracker[request]["received_pending"] += 1
                elif request_info.status == "in_progress":
                    requests_tracker[request]["received_in_progress"] += 1
                    requests_tracker[request]["target_start_time"] = (
                        request_info.timings.targeted_start
                    )
                    requests_tracker[request]["actual_start_time"] = (
                        request_info.timings.resolve_start
                    )
                elif request_info.status == "completed":
                    assert response == f"response_for_{request}"
                    requests_tracker[request]["received_resolved"] += 1
                else:
                    raise ValueError(f"Unexpected status: {request_info.status}")

            # Ensure no extra statuses
            with pytest.raises(asyncio.TimeoutError):
                await main_messaging.get(timeout=0.1)

            # Trigger stopping for constraints and requests
            instance.requests_generated_event.set()
            instance.constraint_reached_event.set()
            await asyncio.sleep(0)

            # Validate request values are correct
            for ind in range(num_requests):
                request = f"request_{ind}"
                assert requests_tracker[request]["received_pending"] == 1
                assert requests_tracker[request]["received_in_progress"] == 1
                assert requests_tracker[request]["received_resolved"] == 1

                bounds = timing_bounds[ind]
                target_offset = (
                    requests_tracker[request]["target_start_time"] - start_time
                )
                actual_offset = (
                    requests_tracker[request]["actual_start_time"] - start_time
                )
                prev_offset = (
                    requests_tracker[f"request_{ind - 1}"]["target_start_time"]
                    - start_time
                    if ind > 0
                    else None
                )

                if bounds.exact is not None:
                    assert target_offset == pytest.approx(
                        bounds.exact, rel=bounds.tolerance
                    )
                    assert target_offset == pytest.approx(
                        actual_offset, rel=bounds.actual_tolerance or bounds.tolerance
                    )
                if bounds.lower is not None:
                    assert target_offset >= bounds.lower - bounds.tolerance
                    assert actual_offset >= bounds.lower - (
                        bounds.actual_tolerance or bounds.tolerance
                    )
                if bounds.upper is not None:
                    assert target_offset <= bounds.upper + bounds.tolerance
                    assert actual_offset <= bounds.upper + (
                        bounds.actual_tolerance or bounds.tolerance
                    )
                if bounds.prev_request is not None and prev_offset is not None:
                    if bounds.prev_request == "greater":
                        assert target_offset > prev_offset - bounds.tolerance
                    elif bounds.prev_request == "greater_equal":
                        assert target_offset >= prev_offset - bounds.tolerance
                    elif bounds.prev_request == "less":
                        assert target_offset < prev_offset + bounds.tolerance
                    elif bounds.prev_request == "less_equal":
                        assert target_offset <= prev_offset + bounds.tolerance
        finally:
            # Trigger shutdown
            instance.shutdown_event.set()
            await asyncio.to_thread(process.join, timeout=2.0)

            if process.is_alive():
                process.terminate()
                await asyncio.to_thread(process.join, timeout=2.0)
            assert process.exitcode <= 0, (
                f"Process exited with error code: {process.exitcode}"
            )

    @pytest.mark.regression
    @pytest.mark.asyncio
    @async_timeout(5)
    async def test_process_requests_awaits_cancellation_before_cancel_loop(
        self,
        valid_instances: tuple[WorkerProcess, InterProcessMessagingQueue, dict],
    ):
        """``_process_requests`` must fully drain ``_process_requests_loop``'s
        own cancellation (which reports each in-flight node's terminal status
        itself) before ``_cancel_requests_loop`` sweeps ``turns_queue``: a
        node cancelled by the sweep while its own task is still finishing is
        exactly the race that double-reports a request's terminal status
        (worker_group.py's ``_update_state_request_counts``).
        ## WRITTEN BY AI ##
        """
        instance, _main_messaging, _constructor_args = valid_instances
        events: list[str] = []
        loop_started = asyncio.Event()

        async def fake_processing_startup():
            events.append("startup")

        async def fake_process_requests_loop():
            loop_started.set()
            try:
                await asyncio.sleep(1000)
            except asyncio.CancelledError:
                events.append("loop_cancel_start")
                # Simulate an in-flight node task still finishing its own
                # cancellation handling (reporting its terminal status).
                await asyncio.sleep(0.05)
                events.append("loop_cancel_done")
                raise

        async def fake_cancel_requests_loop():
            events.append("cancel_requests_loop")

        async def fake_processing_shutdown():
            events.append("shutdown")

        instance._processing_startup = fake_processing_startup
        instance._process_requests_loop = fake_process_requests_loop
        instance._cancel_requests_loop = fake_cancel_requests_loop
        instance._processing_shutdown = fake_processing_shutdown

        process_requests_task = asyncio.create_task(instance._process_requests())
        # Wait until the inner loop is actually suspended on its mock work
        # before triggering the constraint, so cancellation exercises its
        # except-CancelledError handling rather than cancelling a task that
        # never ran.
        await asyncio.wait_for(loop_started.wait(), timeout=2.0)
        instance.constraint_reached_event.set()
        await process_requests_task

        # On `main` this reads ["startup", "cancel_requests_loop", "shutdown"]
        # without "loop_cancel_start"/"loop_cancel_done" ever appearing before
        # it: the cancel loop sweeps turns_queue before the in-flight task's
        # own cancellation handling (and its own terminal-status report) has
        # even started.
        assert events == [
            "startup",
            "loop_cancel_start",
            "loop_cancel_done",
            "cancel_requests_loop",
            "shutdown",
        ]


class MockMessaging:
    """Mock messaging queue for testing worker DAG functionality.

    ## WRITTEN BY AI ##
    """

    def __init__(self, worker_index=1):
        self.worker_index = worker_index
        self.poll_interval = 0.01
        self._queue = []
        self._sent_items = []
        self.get_calls: list[float | None] = []
        self._item_available = asyncio.Event()

    async def get(self, timeout=None):
        """Mock get from queue; honor timeout like InterProcessMessaging."""
        self.get_calls.append(timeout)
        if self._queue:
            item = self._queue.pop(0)
            if not self._queue:
                self._item_available.clear()
            return item
        if timeout is None:
            await self._item_available.wait()
            item = self._queue.pop(0)
            if not self._queue:
                self._item_available.clear()
            return item
        await asyncio.sleep(timeout)
        raise asyncio.TimeoutError("Mock queue empty")

    async def put(self, item, timeout=None):
        """Mock put to queue."""
        self._queue.append(item)
        self._item_available.set()

    def put_sync(self, item, timeout=None):
        """Mock synchronous put."""
        self._sent_items.append(item)
        self._item_available.set()


class TestWorkerProcessMultiturn:
    """Test cases for Worker DAG graph state management.

    ## WRITTEN BY AI ##
    """

    @pytest.fixture
    def worker_instance(self):
        """Create worker instance with mock messaging.

        ## WRITTEN BY AI ##
        """
        return WorkerProcess(
            worker_index=1,
            messaging=MockMessaging(),
            backend=MockBackend(),
            strategy=SynchronousStrategy(),
            async_limit=5,
            fut_scheduling_time_limit=10.0,
            startup_barrier=Barrier(2),
            requests_generated_event=Event(),
            constraint_reached_event=Event(),
            shutdown_event=Event(),
            error_event=Event(),
            stdout_conn=None,
            stderr_conn=None,
            parent_logger=None,
        )

    @pytest.mark.smoke
    def test_turns_queue_initialization(self, worker_instance):
        """Test that turns_queue is initialized as empty list.

        ## WRITTEN BY AI ##
        """
        assert hasattr(worker_instance, "turns_queue")
        assert worker_instance.turns_queue == []

    @pytest.mark.sanity
    @pytest.mark.asyncio
    async def test_get_next_ready_node_waits_for_delay(self, worker_instance):
        """Delayed-only graphs wake without requiring a new IPC graph.

        ## WRITTEN BY AI ##
        """
        nodes = {
            "n0": ConversationNode(
                node_id="n0",
                agent_id="a",
                request="r0",
                settings=RequestSettings(requeue_delay=0.05),
            ),
            "n1": ConversationNode(
                node_id="n1",
                agent_id="a",
                request="r1",
            ),
        }
        graph = ConversationGraph(
            graph_id="delayed",
            nodes=nodes,
            edges=[
                ConversationEdge(
                    source_node_id="n0",
                    target_node_id="n1",
                    history_context="full",
                )
            ],
        )
        state = DAGExecutionState(graph)
        state.mark_completed("n0", "r0", "resp0")
        worker_instance.turns_queue.append(state)

        started = time.time()
        result_state, node_id = await worker_instance._get_next_ready_node()
        elapsed = time.time() - started

        assert result_state is state
        assert node_id == "n1"
        assert elapsed >= 0.04
        assert any(t is not None for t in worker_instance.messaging.get_calls)

    @pytest.mark.sanity
    @pytest.mark.asyncio
    async def test_cancel_clears_delayed_graphs(self, worker_instance):
        """Cancel loop aborts in-flight graphs including delayed children.

        ## WRITTEN BY AI ##
        """
        nodes = {
            "n0": ConversationNode(
                node_id="n0",
                agent_id="a",
                request="r0",
                settings=RequestSettings(requeue_delay=30.0),
            ),
            "n1": ConversationNode(
                node_id="n1",
                agent_id="a",
                request="r1",
            ),
        }
        graph = ConversationGraph(
            graph_id="cancel_delay",
            nodes=nodes,
            edges=[
                ConversationEdge(
                    source_node_id="n0",
                    target_node_id="n1",
                    history_context="full",
                )
            ],
            request_infos={
                "n0": RequestInfo(request_id="id0", node_id="n0"),
                "n1": RequestInfo(request_id="id1", node_id="n1"),
            },
        )
        state = DAGExecutionState(graph)
        state.mark_completed("n0", "r0", "resp0")
        worker_instance.turns_queue.append(state)
        nxt = state.next_node_ready_at()
        assert nxt is not None
        assert nxt[1] > time.time()

        cancel_task = asyncio.create_task(worker_instance._cancel_requests_loop())
        await wait_until(lambda: not worker_instance.turns_queue)
        cancel_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await cancel_task

        assert worker_instance.turns_queue == []
        assert state.is_aborted
        assert state.next_node_ready_at() is None

    @pytest.mark.regression
    @pytest.mark.asyncio
    async def test_cancel_preserves_partial_backend_response(self):
        """Cancelled node update keeps the final partial response from the backend.

        Backends yield a compiled partial result before re-raising CancelledError.
        ``_execute_node`` must yield those chunks so the outer cancel handler can
        publish them.
        ## WRITTEN BY AI ##
        """

        class CancelYieldBackend(MockBackend):
            """Yield a partial response on cancel, matching real backends."""

            def __init__(self):
                super().__init__(lifecycle_delay=0.0, resolve_delay=0.0)
                self.entered_resolve = asyncio.Event()
                self.partial_response = "partial_cancel_response"

            async def resolve(self, request, request_info, request_history):
                self.resolve_called = True
                self.entered_resolve.set()
                try:
                    await asyncio.sleep(1000.0)
                except asyncio.CancelledError as err:
                    yield self.partial_response, request_info
                    raise err

        backend = CancelYieldBackend()
        worker = WorkerProcess(
            worker_index=1,
            messaging=MockMessaging(),
            backend=backend,
            strategy=SynchronousStrategy(),
            async_limit=5,
            fut_scheduling_time_limit=10.0,
            startup_barrier=Barrier(2),
            requests_generated_event=Event(),
            constraint_reached_event=Event(),
            shutdown_event=Event(),
            error_event=Event(),
            stdout_conn=None,
            stderr_conn=None,
            parent_logger=None,
        )
        graph = ConversationGraph(
            graph_id="cancel_partial",
            nodes={
                "n0": ConversationNode(
                    node_id="n0",
                    agent_id="a",
                    request="r0",
                ),
            },
            edges=[],
            request_infos={"n0": RequestInfo(request_id="id0", node_id="n0")},
        )
        await worker.messaging.put(graph)

        task = asyncio.create_task(
            worker._process_next_graph_node(target_start=time.time())
        )
        await backend.entered_resolve.wait()
        await asyncio.sleep(0)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

        cancelled = [
            item
            for item in worker.messaging._sent_items
            if item[2].status == "cancelled"
        ]
        assert len(cancelled) == 1
        response, request, request_info = cancelled[0]
        assert response == backend.partial_response
        assert request == "r0"
        assert request_info.error == "Request was cancelled"

    @pytest.mark.sanity
    @pytest.mark.asyncio
    async def test_execute_node_sets_history_len_and_turn_index(self, worker_instance):
        """history_len is len(history); turn_index is path depth resetting on new.

        At merge m2: history_len=3 ([m0, m1, b1]) while turn_index=2
        (max(turn(m1)+1, 1) = max(2, 1)).

        ## WRITTEN BY AI ##
        """
        nodes = {
            "m0": ConversationNode(node_id="m0", agent_id="main", request="rm0"),
            "m1": ConversationNode(node_id="m1", agent_id="main", request="rm1"),
            "m2": ConversationNode(node_id="m2", agent_id="main", request="rm2"),
            "b0": ConversationNode(node_id="b0", agent_id="worker", request="rb0"),
            "b1": ConversationNode(node_id="b1", agent_id="worker", request="rb1"),
        }
        graph = ConversationGraph(
            graph_id="history_len_turn_index",
            nodes=nodes,
            edges=[
                ConversationEdge(
                    source_node_id="m0",
                    target_node_id="m1",
                    history_context="full",
                ),
                ConversationEdge(
                    source_node_id="m1",
                    target_node_id="m2",
                    history_context="full",
                ),
                ConversationEdge(
                    source_node_id="m0",
                    target_node_id="b0",
                    history_context="new",
                ),
                ConversationEdge(
                    source_node_id="b0",
                    target_node_id="b1",
                    history_context="full",
                ),
                ConversationEdge(
                    source_node_id="b1",
                    target_node_id="m2",
                    history_context="last",
                ),
            ],
        )
        state = DAGExecutionState(graph)
        target_start = time.time()

        info_m0 = RequestInfo(
            request_id="id_m0", node_id="m0", history_len=99, turn_index=99
        )
        async for _ in worker_instance._execute_node(
            state, "m0", "rm0", info_m0, target_start
        ):
            pass
        assert info_m0.history_len == 0
        assert info_m0.turn_index == 0

        state.mark_completed("m0", "rm0", "resp_m0")

        info_m1 = RequestInfo(
            request_id="id_m1", node_id="m1", history_len=99, turn_index=99
        )
        async for _ in worker_instance._execute_node(
            state, "m1", "rm1", info_m1, target_start
        ):
            pass
        assert info_m1.history_len == 1
        assert info_m1.turn_index == 1

        info_b0 = RequestInfo(
            request_id="id_b0", node_id="b0", history_len=99, turn_index=99
        )
        async for _ in worker_instance._execute_node(
            state, "b0", "rb0", info_b0, target_start
        ):
            pass
        assert info_b0.history_len == 0
        assert info_b0.turn_index == 0

        state.mark_completed("b0", "rb0", "resp_b0")

        info_b1 = RequestInfo(
            request_id="id_b1", node_id="b1", history_len=99, turn_index=99
        )
        async for _ in worker_instance._execute_node(
            state, "b1", "rb1", info_b1, target_start
        ):
            pass
        assert info_b1.history_len == 1
        assert info_b1.turn_index == 1

        state.mark_completed("m1", "rm1", "resp_m1")
        state.mark_completed("b1", "rb1", "resp_b1")

        info_m2 = RequestInfo(
            request_id="id_m2", node_id="m2", history_len=99, turn_index=99
        )
        async for _ in worker_instance._execute_node(
            state, "m2", "rm2", info_m2, target_start
        ):
            pass
        assert info_m2.history_len == 3
        assert info_m2.turn_index == 2

    @pytest.mark.sanity
    @pytest.mark.asyncio
    async def test_execute_node_all_new_edges_keeps_turn_index_zero(
        self, worker_instance
    ):
        """history=trace graphs: preceding_nodes increments; turn_index stays 0.

        ## WRITTEN BY AI ##
        """
        nodes = {
            f"main_{i}": ConversationNode(
                node_id=f"main_{i}", agent_id="default", request=f"r{i}"
            )
            for i in range(3)
        }
        graph = ConversationGraph(
            graph_id="otel_trace",
            nodes=nodes,
            edges=[
                ConversationEdge(
                    source_node_id=f"main_{i}",
                    target_node_id=f"main_{i + 1}",
                    history_context="new",
                )
                for i in range(2)
            ],
        )
        state = DAGExecutionState(graph)
        target_start = time.time()

        for i in range(3):
            node_id = f"main_{i}"
            info = RequestInfo(
                request_id=f"id_{node_id}",
                node_id=node_id,
                preceding_nodes=state.preceding_nodes[node_id],
            )
            async for _ in worker_instance._execute_node(
                state, node_id, f"r{i}", info, target_start
            ):
                pass
            assert info.preceding_nodes == i
            assert info.turn_index == 0
            assert info.history_len == 0
            state.mark_completed(node_id, f"r{i}", f"resp_{node_id}")

    @pytest.mark.regression
    @pytest.mark.asyncio
    async def test_worker_index_zero_reported_as_scheduler_node_id(self):
        """Worker 0 must report scheduler_node_id 0, not the unknown sentinel -1.

        ## WRITTEN BY AI ##
        """
        worker = WorkerProcess(
            worker_index=0,
            messaging=MockMessaging(worker_index=0),
            backend=MockBackend(),
            strategy=SynchronousStrategy(),
            async_limit=5,
            fut_scheduling_time_limit=10.0,
            startup_barrier=Barrier(2),
            requests_generated_event=Event(),
            constraint_reached_event=Event(),
            shutdown_event=Event(),
            error_event=Event(),
            stdout_conn=None,
            stderr_conn=None,
            parent_logger=None,
        )
        graph = ConversationGraph(
            graph_id="worker_zero",
            nodes={
                "n0": ConversationNode(node_id="n0", agent_id="a", request="r0"),
                "n1": ConversationNode(node_id="n1", agent_id="a", request="r1"),
            },
            edges=[],
            request_infos={
                "n0": RequestInfo(request_id="id0", node_id="n0"),
                "n1": RequestInfo(request_id="id1", node_id="n1"),
            },
        )
        state = DAGExecutionState(graph)

        # Dequeue path
        _, request_info = worker._prepare_node(state, "n0", target_start=time.time())
        assert request_info.scheduler_node_id == 0

        # Cancel path for graphs still queued on the worker
        worker.turns_queue.append(state)
        cancel_task = asyncio.create_task(worker._cancel_requests_loop())
        await wait_until(
            lambda: any(
                info.status == "cancelled"
                for _, _, info in worker.messaging._sent_items
            )
        )
        cancel_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await cancel_task

        cancelled = [
            info
            for _, _, info in worker.messaging._sent_items
            if info.status == "cancelled"
        ]
        assert cancelled
        assert all(info.scheduler_node_id == 0 for info in cancelled)


class _ChildMockMessaging:
    """Picklable messaging stub for subprocess WorkerProcess.run() tests."""

    def __init__(self, worker_index: int = 0) -> None:
        self.worker_index = worker_index
        self.poll_interval = 0.01

    async def get(self, timeout=None):
        raise asyncio.TimeoutError

    def put_sync(self, item, timeout=-1):
        pass

    async def start(self, receive_stop_criteria=None):
        pass

    async def stop(self):
        pass


class _LoggingWorkerProcess(WorkerProcess):
    """WorkerProcess stub that logs once from run_async."""

    log_message: str = "worker-run-log-msg"

    async def run_async(self):
        logger.info(self.log_message)


def _child_worker_process_run(
    parent_logger,
    stdout_conn,
    stderr_conn,
    log_message: str,
) -> None:
    worker = _LoggingWorkerProcess(
        worker_index=0,
        messaging=_ChildMockMessaging(),
        backend=MockBackend(lifecycle_delay=0.0, resolve_delay=0.0),
        strategy=SynchronousStrategy(),
        async_limit=1,
        fut_scheduling_time_limit=10.0,
        startup_barrier=Barrier(1),
        requests_generated_event=Event(),
        constraint_reached_event=Event(),
        shutdown_event=Event(),
        error_event=Event(),
        stdout_conn=stdout_conn,
        stderr_conn=stderr_conn,
        parent_logger=parent_logger,
    )
    worker.log_message = log_message
    worker.run()


class TestWorkerProcessRun:
    """Tests for WorkerProcess.run() process entrypoint behavior.

    ## WRITTEN BY AI ##
    """

    @staticmethod
    def _mock_asyncio_run(mocker):
        def _consume_coro(coro):
            coro.close()

        return mocker.patch(
            "guidellm.scheduler.worker.asyncio.run",
            side_effect=_consume_coro,
        )

    @staticmethod
    def _build_worker(
        *,
        stdout_conn=None,
        stderr_conn=None,
        parent_logger=None,
    ) -> WorkerProcess:
        return WorkerProcess(
            worker_index=0,
            messaging=MockMessaging(),
            backend=MockBackend(lifecycle_delay=0.0, resolve_delay=0.0),
            strategy=SynchronousStrategy(),
            async_limit=1,
            fut_scheduling_time_limit=10.0,
            startup_barrier=Barrier(1),
            requests_generated_event=Event(),
            constraint_reached_event=Event(),
            shutdown_event=Event(),
            error_event=Event(),
            stdout_conn=stdout_conn,
            stderr_conn=stderr_conn,
            parent_logger=parent_logger,
        )

    @pytest.mark.sanity
    def test_run_skips_stdio_redirect_when_pipes_are_none(self, mocker):
        """
        run() leaves stdio untouched when pipe connections are not provided.

        ## WRITTEN BY AI ##
        """
        mock_dup2 = mocker.patch("guidellm.scheduler.worker.os.dup2")
        self._mock_asyncio_run(mocker)
        self._build_worker().run()
        mock_dup2.assert_not_called()

    @pytest.mark.sanity
    def test_run_redirects_stdio_when_pipes_are_set(self, mocker):
        """
        run() redirects stdout/stderr before executing worker logic.

        ## WRITTEN BY AI ##
        """
        mock_dup2 = mocker.patch("guidellm.scheduler.worker.os.dup2")
        self._mock_asyncio_run(mocker)
        stdout_conn = mocker.MagicMock()
        stderr_conn = mocker.MagicMock()
        self._build_worker(
            stdout_conn=stdout_conn,
            stderr_conn=stderr_conn,
        ).run()
        assert mock_dup2.call_count == 2
        stdout_conn.close.assert_called_once()
        stderr_conn.close.assert_called_once()

    @pytest.mark.sanity
    def test_run_reinstalls_logger_when_parent_logger_is_set(self, mocker):
        """
        run() reinstalls the parent logger before asyncio startup.

        ## WRITTEN BY AI ##
        """
        mock_reinstall = mocker.patch(
            "guidellm.scheduler.worker.reinstall_inherited_logger"
        )
        self._mock_asyncio_run(mocker)
        parent = mocker.MagicMock()
        self._build_worker(parent_logger=parent).run()
        mock_reinstall.assert_called_once_with(parent)

    @pytest.mark.sanity
    def test_run_skips_logger_reinstall_when_parent_logger_is_none(self, mocker):
        """
        run() skips logger reinstall when no parent logger is provided.

        ## WRITTEN BY AI ##
        """
        mock_reinstall = mocker.patch(
            "guidellm.scheduler.worker.reinstall_inherited_logger"
        )
        self._mock_asyncio_run(mocker)
        self._build_worker().run()
        mock_reinstall.assert_not_called()

    @pytest.mark.sanity
    def test_run_calls_logger_complete(self, mocker):
        """
        run() always drains enqueued log records on exit.

        ## WRITTEN BY AI ##
        """
        mock_complete = mocker.patch("guidellm.scheduler.worker.logger.complete")
        self._mock_asyncio_run(mocker)
        self._build_worker().run()
        mock_complete.assert_called_once()

    @pytest.mark.regression
    @pytest.mark.parametrize("ctx_name", ["spawn", "forkserver"])
    def test_run_entrypoint_inherits_parent_logger(self, ctx_name, capsys):
        """
        WorkerProcess.run() emits logs through inherited parent handlers.

        ## WRITTEN BY AI ##
        """
        ctx = mp.get_context(ctx_name)
        configure_logger(config=LoggingSettings(console_log_level="INFO"))
        message = f"worker-run-{ctx_name}"
        p = ctx.Process(
            target=_child_worker_process_run,
            args=(logger, None, None, message),
        )
        p.start()
        p.join(timeout=10)
        assert p.exitcode == 0

        logger.complete()
        captured = capsys.readouterr()
        assert message in captured.err
        assert "|INFO     |" in captured.err

    @pytest.mark.sanity
    def test_run_entrypoint_routes_stdio_through_pipes(self, capsys):
        """
        WorkerProcess.run() redirects stdio through pipes for parent capture.

        ## WRITTEN BY AI ##
        """
        ctx = mp.get_context("spawn")
        configure_logger(config=LoggingSettings(console_log_level="INFO"))
        stdout_reader, stdout_writer = ctx.Pipe(duplex=False)
        stderr_reader, stderr_writer = ctx.Pipe(duplex=False)
        message = "worker-run-pipe-msg"
        reader = PipeReaderThread(stdout_reader, stderr_reader)
        reader.start()
        try:
            p = ctx.Process(
                target=_child_worker_process_run,
                args=(logger, stdout_writer, stderr_writer, message),
            )
            p.start()
            stdout_writer.close()
            stderr_writer.close()
            p.join(timeout=10)
            time.sleep(0.2)
            assert p.exitcode == 0
            logger.complete()
            captured = capsys.readouterr()
            assert message in captured.err
        finally:
            reader.stop()
