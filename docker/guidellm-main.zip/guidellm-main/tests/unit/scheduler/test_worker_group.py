from __future__ import annotations

import asyncio
import inspect
import multiprocessing
import threading
import time
from multiprocessing.context import BaseContext
from multiprocessing.managers import BaseManager
from multiprocessing.process import BaseProcess
from multiprocessing.synchronize import Barrier, Event
from typing import Any, Generic, Literal, cast
from unittest.mock import Mock, patch

import pytest
from pydantic import Field

from guidellm.scheduler import (
    AsyncConstantStrategy,
    BackendInterface,
    ConcurrentStrategy,
    MaxDurationConstraint,
    MaxNumberConstraint,
    SchedulerState,
    SynchronousStrategy,
    ThroughputStrategy,
    WorkerProcessGroup,
)
from guidellm.scheduler.schemas import ConversationGraph, ConversationNode
from guidellm.scheduler.worker_group import WorkerGroupState
from guidellm.schemas import RequestInfo, RequestTimings
from guidellm.schemas.scheduler import (
    MaxDurationConstraintArgs,
    MaxRequestsConstraintArgs,
)
from guidellm.utils.messaging import InterProcessMessaging
from tests.unit.testing_utils import async_timeout


class MockRequestTimings(RequestTimings):
    """Mock timing implementation for testing."""

    timings_type: Literal["mock"] = Field(default="mock")


class MockTime:
    """Deterministic time mock for testing."""

    def __init__(self, start_time: float = 1000.0):
        self.current_time = start_time
        self.increment = 0.1

    def time(self) -> float:
        """Return current mock time and increment for next call."""
        current = self.current_time
        self.current_time += self.increment
        return current


mock_time = MockTime()


class MockBackend(BackendInterface):
    """Mock backend for testing worker group functionality."""

    def __init__(
        self,
        processes_limit_value: int | None = None,
        requests_limit_value: int | None = None,
    ):
        self._processes_limit = processes_limit_value
        self._requests_limit = requests_limit_value

    @property
    def processes_limit(self) -> int | None:
        return self._processes_limit

    @property
    def requests_limit(self) -> int | None:
        return self._requests_limit

    @property
    def info(self) -> dict[str, Any]:
        return {"type": "mock"}

    async def process_startup(self):
        pass

    async def validate(self):
        pass

    async def process_shutdown(self):
        pass

    async def resolve(self, request, request_info, request_history):
        request_info.timings = MockRequestTimings(
            request_start=time.time(), request_end=time.time()
        )
        yield f"response_for_{request}", request_info


class TestWorkerProcessGroup:
    """Test suite for WorkerProcessGroup class."""

    def setup_method(self):
        pass

    def teardown_method(self):
        pass

    @pytest.fixture(
        params=[
            {
                "requests": ["request1", "request2", "request3"],
                "strategy": SynchronousStrategy(),
                "startup_duration": 0.1,
                "max_requests": MaxNumberConstraint(
                    args=MaxRequestsConstraintArgs(count=10),
                ),
            },
            {
                "requests": ["req_a", "req_b"],
                "strategy": ConcurrentStrategy(streams=2),
                "startup_duration": 0.1,
                "max_requests": MaxNumberConstraint(
                    args=MaxRequestsConstraintArgs(count=5),
                ),
            },
            {
                "requests": ["req_x", "req_y", "req_z"],
                "strategy": ThroughputStrategy(max_concurrency=5),
                "startup_duration": 0.1,
            },
            {
                "requests": ["req_8", "req_9", "req_10"],
                "strategy": AsyncConstantStrategy(rate=20),
                "startup_duration": 0.1,
                "max_duration": MaxDurationConstraint(
                    args=MaxDurationConstraintArgs(seconds=1),
                ),
            },
        ],
        ids=["sync_max", "concurrent_max", "throughput_no_cycle", "constant_duration"],
    )
    def valid_instances(self, request):
        """Fixture providing test data for WorkerProcessGroup."""
        constructor_args = request.param.copy()
        base_params = {
            k: v
            for k, v in request.param.items()
            if k in ["requests", "strategy", "startup_duration"]
        }
        constraint_params = {
            k: v
            for k, v in request.param.items()
            if k not in ["requests", "strategy", "startup_duration"]
        }
        instance = WorkerProcessGroup(
            **base_params, backend=MockBackend(), **constraint_params
        )
        yield instance, constructor_args

        # Shutting down. Attempting shut down.
        try:
            if hasattr(instance, "processes") and instance.processes is not None:
                asyncio.run(instance.shutdown())
        # It's not...it's-it's not...it's not shutting down...it's not...
        except Exception:  # noqa: BLE001
            if hasattr(instance, "processes") and instance.processes is not None:
                # Gahhh...!
                for proc in instance.processes:
                    proc.kill()
                    proc.join(timeout=1.0)

    @pytest.mark.smoke
    def test_class_signatures(self, valid_instances):
        """Test inheritance and type relationships."""
        instance, _ = valid_instances

        # Class
        assert isinstance(instance, Generic)
        assert issubclass(WorkerProcessGroup, Generic)

        # Generics
        orig_bases = getattr(WorkerProcessGroup, "__orig_bases__", ())
        assert len(orig_bases) > 0
        generic_base = next(
            (
                base
                for base in orig_bases
                if hasattr(base, "__origin__") and base.__origin__ is Generic
            ),
            None,
        )
        assert generic_base is not None
        type_args = getattr(generic_base, "__args__", ())
        assert len(type_args) == 2

        # Function signatures
        create_processes_sig = inspect.signature(WorkerProcessGroup.create_processes)
        assert len(create_processes_sig.parameters) == 1
        assert "self" in create_processes_sig.parameters

        start_sig = inspect.signature(WorkerProcessGroup.start)
        assert len(start_sig.parameters) == 2
        assert "self" in start_sig.parameters
        assert "start_time" in start_sig.parameters

        request_updates_sig = inspect.signature(WorkerProcessGroup.request_updates)
        assert len(request_updates_sig.parameters) == 1
        assert "self" in request_updates_sig.parameters

        shutdown_sig = inspect.signature(WorkerProcessGroup.shutdown)
        assert len(shutdown_sig.parameters) == 1
        assert "self" in shutdown_sig.parameters

    @pytest.mark.smoke
    def test_initialization(self, valid_instances):
        """Test basic initialization of WorkerProcessGroup."""
        instance, constructor_args = valid_instances

        # Core attributes
        assert isinstance(instance.backend, MockBackend)
        # requests is now an iterator, not a list
        assert hasattr(instance.requests, "__iter__")
        assert hasattr(instance.requests, "__next__")
        assert isinstance(instance.strategy, type(constructor_args["strategy"]))
        assert isinstance(instance.constraints, dict)

        # Multiprocessing attributes (should be None initially)
        assert instance.mp_context is None
        assert instance.mp_manager is None
        assert instance.processes is None

        # Synchronization primitives (should be None initially)
        assert instance.startup_barrier is None
        assert instance.shutdown_event is None
        assert instance.error_event is None
        assert instance.requests_generated_event is None
        assert instance.constraint_reached_event is None

        # Scheduler state and messaging (should be None initially)
        assert instance.state is None
        assert instance.messaging is None

    @pytest.mark.sanity
    @pytest.mark.parametrize(
        ("requests", "expected_error"),
        [
            (None, TypeError),
        ],
        ids=["no_requests"],
    )
    def test_invalid_initialization_values(self, requests, expected_error):
        """Test WorkerProcessGroup with invalid initialization values."""
        with pytest.raises(expected_error):
            WorkerProcessGroup(
                requests=requests,
                backend=MockBackend(),
                strategy=SynchronousStrategy(),
            )

    @pytest.mark.sanity
    def test_invalid_initialization_missing(self):
        """Test WorkerProcessGroup initialization without required fields."""
        with pytest.raises(TypeError):
            WorkerProcessGroup()

    @pytest.mark.regression
    @pytest.mark.asyncio
    async def test_request_updates_swallows_asyncio_timeout_error(self):
        """Idle polls from asyncio.wait_for must not abort request_updates.

        On Python 3.10, asyncio.TimeoutError is not builtin TimeoutError, so the
        poll loop must catch the asyncio type that wait_for actually raises.

        ## WRITTEN BY AI ##
        """
        group = WorkerProcessGroup(
            requests=["req"],
            backend=MockBackend(),
            strategy=SynchronousStrategy(),
        )
        error_event = Mock()
        error_event.is_set.return_value = False
        shutdown_event = Mock()
        shutdown_checks = 0

        def shutdown_is_set() -> bool:
            nonlocal shutdown_checks
            shutdown_checks += 1
            return shutdown_checks > 1

        shutdown_event.is_set.side_effect = shutdown_is_set
        group.error_event = error_event
        group.shutdown_event = shutdown_event
        group.constraint_reached_event = Mock()
        group.constraint_reached_event.is_set.return_value = False
        state_update = Mock()
        state_update.stop_processing = False
        state_update.stop_queueing = False
        group.state = Mock()
        group.state.update_state.return_value = state_update

        payload = (None, "req", Mock(), Mock())
        get_calls = 0

        async def mock_get(*, timeout: float | None = None):
            nonlocal get_calls
            get_calls += 1
            if get_calls == 2:
                return payload
            raise asyncio.TimeoutError

        group.messaging = Mock()
        group.messaging.get = mock_get

        results = [update async for update in group.request_updates()]

        assert results == [payload]
        assert get_calls == 3
        group.state.update_state.assert_called()

    @pytest.mark.regression
    @pytest.mark.asyncio
    async def test_request_updates_skips_constraint_eval_when_shutdown(self):
        """Idle timeout with shutdown already set must not re-evaluate constraints.

        ## WRITTEN BY AI ##
        """
        group = WorkerProcessGroup(
            requests=["req"],
            backend=MockBackend(),
            strategy=SynchronousStrategy(),
        )
        error_event = Mock()
        error_event.is_set.return_value = False
        shutdown_event = Mock()
        shutdown_event.is_set.return_value = True
        group.error_event = error_event
        group.shutdown_event = shutdown_event
        group.state = Mock()

        async def mock_get(*, timeout: float | None = None):
            raise asyncio.TimeoutError

        group.messaging = Mock()
        group.messaging.get = mock_get

        results = [update async for update in group.request_updates()]

        assert results == []
        group.state.update_state.assert_not_called()

    @pytest.mark.xfail(reason="old and broken", run=False)
    @pytest.mark.smoke
    @async_timeout(10)
    @pytest.mark.asyncio
    @patch.object(time, "time", mock_time.time)
    async def test_lifecycle(self, valid_instances: tuple[WorkerProcessGroup, dict]):  # noqa: C901, PLR0912
        """Test the lifecycle methods of WorkerProcessGroup."""
        instance, constructor_args = valid_instances
        assert instance.requests or instance.cycle_requests
        assert instance.backend
        assert instance.strategy
        assert instance.constraints is not None

        # Validate create_processes works and sets correct state
        await instance.create_processes()
        assert instance.mp_context is not None
        assert isinstance(instance.mp_context, BaseContext)
        assert instance.mp_manager is not None
        assert isinstance(instance.mp_manager, BaseManager)
        assert instance.processes is not None
        assert isinstance(instance.processes, list)
        assert len(instance.processes) > 0
        assert all(isinstance(proc, BaseProcess) for proc in instance.processes)
        assert all(proc.is_alive() for proc in instance.processes)
        assert instance.startup_barrier is not None
        assert isinstance(instance.startup_barrier, Barrier)
        assert instance.requests_generated_event is not None
        assert isinstance(instance.requests_generated_event, Event)
        assert instance.constraint_reached_event is not None
        assert isinstance(instance.constraint_reached_event, Event)
        assert instance.shutdown_event is not None
        assert isinstance(instance.shutdown_event, Event)
        assert instance.error_event is not None
        assert isinstance(instance.error_event, Event)
        assert instance.messaging is not None
        assert isinstance(instance.messaging, InterProcessMessaging)
        assert instance.messaging.worker_index is None

        # Validate start works and sets correct state
        start_time = time.time() + 0.1
        await instance.start(start_time=start_time)
        assert instance.state is not None
        assert isinstance(instance.state, WorkerGroupState)
        assert not instance.requests_generated_event.is_set()
        assert not instance.constraint_reached_event.is_set()
        assert not instance.shutdown_event.is_set()
        assert not instance.error_event.is_set()

        # Test iter updates
        requests_tracker = {}

        async for (
            response,
            request,
            request_info,
            scheduler_state,
        ) in instance.request_updates():
            # Validate returned request
            assert request is not None

            # Validate returned request info and response
            assert request_info is not None
            assert isinstance(request_info, RequestInfo)
            assert request_info.request_id is not None
            assert request_info.status is not None
            if request_info.request_id not in requests_tracker:
                requests_tracker[request_info.request_id] = {
                    "received_pending": 0,
                    "received_in_progress": 0,
                    "received_resolved": 0,
                    "received_cancelled": 0,
                }
            assert request_info.scheduler_node_id > -1
            assert request_info.scheduler_process_id > -1
            assert request_info.scheduler_start_time == start_time
            assert request_info.scheduler_timings is not None
            if request_info.status == "pending":
                requests_tracker[request_info.request_id]["received_pending"] += 1
                assert request_info.scheduler_timings.dequeued is not None
                assert request_info.scheduler_timings.targeted_start is not None
                assert request_info.scheduler_timings.targeted_start >= start_time
            elif request_info.status == "in_progress":
                requests_tracker[request_info.request_id]["received_in_progress"] += 1
                assert request_info.scheduler_timings.scheduled_at is not None
                assert (
                    request_info.scheduler_timings.scheduled_at
                    >= request_info.scheduler_timings.dequeued
                )
                assert request_info.scheduler_timings.resolve_start is not None
                assert (
                    request_info.scheduler_timings.resolve_start
                    >= request_info.scheduler_timings.scheduled_at
                )
            elif request_info.status == "completed":
                requests_tracker[request_info.request_id]["received_resolved"] += 1
                assert response is not None
                assert request_info.scheduler_timings.resolve_end is not None
                assert (
                    request_info.scheduler_timings.resolve_end
                    > request_info.scheduler_timings.resolve_start
                )
                assert request_info.request_timings is not None
                assert isinstance(request_info.request_timings, MockRequestTimings)
                assert request_info.request_timings.request_start is not None
                assert (
                    request_info.request_timings.request_start
                    >= request_info.scheduler_timings.targeted_start
                )
                assert request_info.request_timings.request_end is not None
                assert (
                    request_info.request_timings.request_end
                    >= request_info.request_timings.request_start
                )
            elif request_info.status in ("errored", "cancelled"):
                assert response is None
                requests_tracker[request_info.request_id]["received_resolved"] += 1
                assert request_info.scheduler_timings.resolve_end is not None
                assert (
                    request_info.scheduler_timings.resolve_end
                    > request_info.scheduler_start_time
                )
                if request_info.status == "cancelled":
                    requests_tracker[request_info.request_id]["received_cancelled"] += 1

            # Validate state structure
            assert scheduler_state is not None
            assert isinstance(scheduler_state, SchedulerState)
            assert scheduler_state.node_id > -1
            assert scheduler_state.start_time == start_time
            assert scheduler_state.end_time is not None
            if constructor_args.get("constraints"):
                assert scheduler_state.remaining_fraction is not None
                assert scheduler_state.remaining_fraction >= 0.0
                assert scheduler_state.remaining_fraction <= 1.0
            if constructor_args.get("constraints", {}).get("max_requests") is not None:
                assert scheduler_state.remaining_requests is not None
                assert scheduler_state.remaining_requests >= 0
                assert (
                    scheduler_state.remaining_requests
                    <= constructor_args["constraints"]["max_requests"].max_num
                )
            if constructor_args.get("constraints", {}).get("max_duration") is not None:
                assert scheduler_state.remaining_duration is not None
                assert scheduler_state.remaining_duration >= 0.0
                assert (
                    scheduler_state.remaining_duration
                    <= constructor_args["constraints"]["max_duration"].max_duration
                )
            assert scheduler_state.created_requests >= 0
            assert scheduler_state.queued_requests >= 0
            assert scheduler_state.pending_requests >= 0
            assert scheduler_state.processing_requests >= 0
            assert scheduler_state.processed_requests >= 0
            assert scheduler_state.successful_requests >= 0
            assert scheduler_state.errored_requests >= 0
            assert scheduler_state.cancelled_requests >= 0

        # Validate correctness of all updates
        for _, counts in requests_tracker.items():
            assert counts["received_cancelled"] in (0, 1)
            if counts["received_cancelled"] == 0:
                assert counts["received_pending"] == 1
                assert counts["received_in_progress"] >= 1
                assert counts["received_resolved"] == 1
        assert scheduler_state is not None  # last yielded state
        assert scheduler_state.end_time > scheduler_state.start_time
        assert scheduler_state.end_queuing_time is not None
        assert scheduler_state.end_queuing_constraints is not None
        assert scheduler_state.end_processing_time is not None
        assert scheduler_state.end_processing_time >= scheduler_state.start_time
        assert scheduler_state.end_processing_constraints is not None
        assert scheduler_state.scheduler_constraints is not None
        assert scheduler_state.created_requests == len(requests_tracker)
        assert scheduler_state.queued_requests == 0
        assert scheduler_state.pending_requests == 0
        assert scheduler_state.processing_requests == 0
        assert scheduler_state.processed_requests == len(requests_tracker)
        assert scheduler_state.successful_requests >= 0
        assert scheduler_state.errored_requests >= 0
        assert scheduler_state.cancelled_requests >= 0
        assert (
            scheduler_state.successful_requests
            + scheduler_state.errored_requests
            + scheduler_state.cancelled_requests
            == len(requests_tracker)
        )
        if constructor_args.get("constraints"):
            assert list(scheduler_state.scheduler_constraints.keys()) == list(
                constructor_args["constraints"].keys()
            )
            assert scheduler_state.remaining_fraction == 0.0
            if "max_requests" in constructor_args["constraints"]:
                assert "max_requests" in scheduler_state.end_queuing_constraints
                assert "max_requests" in scheduler_state.end_processing_constraints
                max_num = constructor_args["constraints"]["max_requests"].max_num
                assert scheduler_state.created_requests == max_num
                assert scheduler_state.successful_requests == max_num
                assert scheduler_state.errored_requests == 0
                assert scheduler_state.cancelled_requests == 0
            if "max_duration" in constructor_args["constraints"]:
                assert "max_duration" in scheduler_state.end_queuing_constraints
                assert "max_duration" in scheduler_state.end_processing_constraints
                assert scheduler_state.remaining_duration == 0.0
        else:
            assert "requests_exhausted" in scheduler_state.scheduler_constraints
            assert "requests_exhausted" in scheduler_state.end_queuing_constraints
            assert "requests_exhausted" in scheduler_state.end_processing_constraints
            assert scheduler_state.remaining_fraction is None
            assert scheduler_state.remaining_requests is None
            assert scheduler_state.remaining_duration is None

        # Test shutdown
        exceptions = await instance.shutdown()

        # Check valid shutdown behavior
        assert isinstance(exceptions, list)
        assert len(exceptions) == 0
        assert instance.messaging is None
        assert instance.state is None
        assert instance.processes is None
        assert instance.startup_barrier is None
        assert instance.requests_generated_event is None
        assert instance.constraint_reached_event is None
        assert instance.shutdown_event is None
        assert instance.error_event is None
        assert instance.mp_manager is None
        assert instance.mp_context is None


class TestWorkerGroupStateDuplicateTerminalUpdate:
    """
    Regression coverage for a request receiving two terminal status updates:
    once from the worker's cancel loop (which aborts every node not yet in
    the DAG's completed set, including one an in-flight task still owns) and
    once from that task's own completion/cancellation handling. ## WRITTEN BY AI ##
    """

    def _build_state(self) -> WorkerGroupState:
        return WorkerGroupState(
            start_time=time.time(),
            processes=[],
            strategy=SynchronousStrategy(),
            constraints={},
            stop_send_requests_event=threading.Event(),
            send_requests_stopped_event=threading.Event(),
            requests_generated_event=multiprocessing.Event(),
            constraint_reached_event=multiprocessing.Event(),
            shutdown_event=multiprocessing.Event(),
            error_event=multiprocessing.Event(),
            messaging=None,
        )

    def _advance(
        self, state: WorkerGroupState, request_id: str, status: str
    ) -> RequestInfo:
        info = RequestInfo(request_id=request_id, status=status)
        state.received_callback((None, f"request-{request_id}", info))
        return info

    @pytest.mark.regression
    def test_cancel_loop_then_in_flight_completion_does_not_raise_or_double_count(
        self,
    ):
        """A 'cancelled' update (cancel loop) followed by a stray 'completed'
        for the same request (the task that was already reported cancelled
        finishing anyway) must not raise and must not double-count.
        ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending", "in_progress"):
            self._advance(state, "req-1", status)

        self._advance(state, "req-1", "cancelled")
        # Must not raise KeyError: on `main` this crashes inside
        # `_update_state_request_counts` because "completed" unconditionally
        # removes from `_processing_request_ids`, which "cancelled" already did.
        self._advance(state, "req-1", "completed")

        assert state._state.processed_requests == 1
        assert state._state.cancelled_requests == 1
        assert state._state.successful_requests == 0
        assert state._state.processing_requests == 0

    @pytest.mark.regression
    def test_in_flight_completion_then_stray_cancel_does_not_double_count(self):
        """The other interleaving: the in-flight task's own 'completed'
        update lands first, and a stray 'cancelled' for the same request
        (e.g. from a cancel loop that started before completion but was
        delayed) arrives after. On `main` this does not raise (the
        "cancelled" branch's remove is already guarded) but silently
        double-counts `processed_requests`. ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending", "in_progress"):
            self._advance(state, "req-2", status)

        self._advance(state, "req-2", "completed")
        self._advance(state, "req-2", "cancelled")

        assert state._state.processed_requests == 1
        assert state._state.successful_requests == 1
        assert state._state.cancelled_requests == 0

    @pytest.mark.regression
    def test_normal_single_terminal_update_still_counts(self):
        """Control: the ordinary, non-racing lifecycle still counts exactly
        once, so the new guards do not mask a real update. ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending", "in_progress", "completed"):
            self._advance(state, "req-3", status)

        assert state._state.processed_requests == 1
        assert state._state.successful_requests == 1
        assert state._state.queued_requests == 0
        assert state._state.pending_requests == 0
        assert state._state.processing_requests == 0

    @pytest.mark.regression
    def test_stray_pending_after_finalization_is_ignored(self):
        """A stray 'pending' update for a request already finalized (e.g. an
        out-of-order / duplicate delivery) must not raise and must not
        resurrect the request into `_pending_request_ids`. ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending", "in_progress", "cancelled"):
            self._advance(state, "req-4", status)

        self._advance(state, "req-4", "pending")

        assert state._state.processed_requests == 1
        assert state._state.cancelled_requests == 1
        assert state._state.pending_requests == 0
        assert "req-4" not in state._pending_request_ids

    @pytest.mark.regression
    def test_stray_in_progress_after_finalization_is_ignored(self):
        """Same as above for a stray 'in_progress' update after the request
        already reached a terminal state. ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending", "in_progress", "completed"):
            self._advance(state, "req-5", status)

        self._advance(state, "req-5", "in_progress")

        assert state._state.processed_requests == 1
        assert state._state.successful_requests == 1
        assert state._state.processing_requests == 0
        assert "req-5" not in state._processing_request_ids

    @pytest.mark.regression
    def test_cancelled_while_still_queued_is_finalized_from_queued_set(self):
        """A request cancelled before it was ever dispatched (still in
        `_queued_request_ids`, no 'pending'/'in_progress' update yet) must be
        finalized from the queued set, not just the pending/processing ones.
        ## WRITTEN BY AI ##
        """
        state = self._build_state()
        self._advance(state, "req-6", "queued")

        self._advance(state, "req-6", "cancelled")

        assert state._state.processed_requests == 1
        assert state._state.cancelled_requests == 1
        assert state._state.queued_requests == 0
        assert "req-6" not in state._queued_request_ids

    @pytest.mark.regression
    def test_errored_while_pending_is_finalized_from_pending_set(self):
        """A request that errors after being dispatched but before entering
        `_processing_request_ids` (still in `_pending_request_ids`) must be
        finalized from the pending set. ## WRITTEN BY AI ##
        """
        state = self._build_state()
        for status in ("queued", "pending"):
            self._advance(state, "req-7", status)

        self._advance(state, "req-7", "errored")

        assert state._state.processed_requests == 1
        assert state._state.errored_requests == 1
        assert state._state.pending_requests == 0
        assert "req-7" not in state._pending_request_ids


class TestWorkerGroupStateUpdate:
    @pytest.mark.smoke
    def test_update_state_max_duration_without_request(self):
        """Elapsed max_duration stops processing on a state-only update.

        ## WRITTEN BY AI ##
        """
        start_time = time.time() - 10.0
        constraint = MaxDurationConstraint(args=MaxDurationConstraintArgs(seconds=1.0))
        group_state = WorkerGroupState(
            start_time=start_time,
            processes=[],
            strategy=SynchronousStrategy(),
            constraints={"max_duration": constraint},
            stop_send_requests_event=threading.Event(),
            send_requests_stopped_event=threading.Event(),
            requests_generated_event=threading.Event(),
            constraint_reached_event=threading.Event(),
            shutdown_event=threading.Event(),
            error_event=threading.Event(),
            messaging=Mock(),
        )
        update = group_state.update_state()
        assert update.stop_processing
        assert update.stop_queueing
        assert group_state._state.end_processing_time is not None
        assert "max_duration" in group_state._state.end_processing_constraints


class _HangUntilSignaledProcess:
    """Process double that stays alive until terminate or kill is called."""

    def __init__(self, *, die_on: str):
        self.pid = 4242
        self.exitcode: int | None = None
        self._alive = True
        self._die_on = die_on
        self.terminate_calls = 0
        self.kill_calls = 0
        self.join_timeouts: list[float | None] = []

    def is_alive(self) -> bool:
        return self._alive

    def join(self, timeout: float | None = None) -> None:
        self.join_timeouts.append(timeout)
        if not self._alive:
            return

    def terminate(self) -> None:
        self.terminate_calls += 1
        if self._die_on == "terminate":
            self._alive = False
            self.exitcode = -15

    def kill(self) -> None:
        self.kill_calls += 1
        if self._die_on == "kill":
            self._alive = False
            self.exitcode = -9


class TestWorkerProcessGroupForcedShutdown:
    """Shutdown must not block forever on workers that ignore the stop event."""

    def _group_with_process(
        self, proc: _HangUntilSignaledProcess
    ) -> tuple[WorkerProcessGroup, Mock, Mock]:
        group = WorkerProcessGroup(
            requests=["req"],
            backend=MockBackend(),
            strategy=SynchronousStrategy(),
        )
        shutdown_event = Mock()
        mp_manager = Mock()
        group.processes = [cast("BaseProcess", proc)]
        group.shutdown_event = shutdown_event
        group.mp_manager = mp_manager
        return group, shutdown_event, mp_manager

    @pytest.mark.sanity
    @pytest.mark.asyncio
    @async_timeout(5.0)
    async def test_shutdown_terminates_worker_that_ignores_join(self):
        """Workers still alive after join timeout are SIGTERM'd.

        ## WRITTEN BY AI ##
        """
        proc = _HangUntilSignaledProcess(die_on="terminate")
        group, shutdown_event, mp_manager = self._group_with_process(proc)

        exceptions = await group.shutdown()

        assert exceptions == []
        assert proc.terminate_calls == 1
        assert proc.kill_calls == 0
        assert proc.join_timeouts == [5.0, 2.0]
        mp_manager.shutdown.assert_called_once()
        shutdown_event.set.assert_called_once()

    @pytest.mark.sanity
    @pytest.mark.asyncio
    @async_timeout(5.0)
    async def test_shutdown_kills_worker_that_ignores_terminate(self):
        """Workers that ignore SIGTERM are SIGKILL'd.

        ## WRITTEN BY AI ##
        """
        proc = _HangUntilSignaledProcess(die_on="kill")
        group, shutdown_event, mp_manager = self._group_with_process(proc)

        exceptions = await group.shutdown()

        assert exceptions == []
        assert proc.terminate_calls == 1
        assert proc.kill_calls == 1
        assert proc.join_timeouts == [5.0, 2.0, 2.0]
        mp_manager.shutdown.assert_called_once()
        shutdown_event.set.assert_called_once()


def _single_node_graph(graph_id: str, request: str = "r0") -> ConversationGraph[str]:
    return ConversationGraph(
        graph_id=graph_id,
        nodes={
            "n0": ConversationNode(node_id="n0", agent_id="agent", request=request),
        },
        edges=[],
    )


class TestRequestsGeneratorGenerationDelay:
    """Record conversation-level generation_delay on scheduler state.

    ## WRITTEN BY AI ##
    """

    def _build_state(self) -> WorkerGroupState:
        messaging = Mock()
        messaging.buffer_receive_queue = Mock()
        return WorkerGroupState(
            start_time=time.time(),
            processes=[],
            strategy=SynchronousStrategy(),
            constraints={},
            stop_send_requests_event=threading.Event(),
            send_requests_stopped_event=threading.Event(),
            requests_generated_event=multiprocessing.Event(),
            constraint_reached_event=multiprocessing.Event(),
            shutdown_event=multiprocessing.Event(),
            error_event=multiprocessing.Event(),
            messaging=messaging,
        )

    @pytest.mark.sanity
    def test_stamps_generation_delay_including_dataset_wait(self):
        """
        Generation delay includes time spent waiting on the dataset iterator.

        ## WRITTEN BY AI ##
        """
        state = self._build_state()
        dataset_delay = 0.05

        def slow_graphs():
            time.sleep(dataset_delay)
            yield _single_node_graph("g1")

        yielded = list(state.requests_generator(slow_graphs()))

        assert len(yielded) == 1
        assert len(state._state.generation_delay_samples) == 1
        assert state._state.generation_delay_samples[0] >= dataset_delay

    @pytest.mark.sanity
    def test_generation_delay_excludes_time_suspended_after_yield(self):
        """
        Time the consumer waits before pulling the next conversation is not
        counted in the following sample.

        ## WRITTEN BY AI ##
        """
        state = self._build_state()
        graphs = (
            _single_node_graph("g1", "r1"),
            _single_node_graph("g2", "r2"),
        )
        generator = state.requests_generator(graphs)

        next(generator)
        time.sleep(0.1)
        next(generator)

        samples = state._state.generation_delay_samples
        assert len(samples) == 2
        assert samples[1] < 0.05

    @pytest.mark.sanity
    def test_records_generation_delay_once_per_conversation(self):
        """
        Multi-node conversations contribute a single generation delay sample.

        ## WRITTEN BY AI ##
        """
        state = self._build_state()
        graph = ConversationGraph(
            graph_id="g1",
            nodes={
                "n0": ConversationNode(node_id="n0", agent_id="agent", request="r0"),
                "n1": ConversationNode(node_id="n1", agent_id="agent", request="r1"),
            },
            edges=[],
        )

        yielded = list(state.requests_generator([graph]))

        assert len(yielded[0].request_infos) == 2
        assert len(state._state.generation_delay_samples) == 1
