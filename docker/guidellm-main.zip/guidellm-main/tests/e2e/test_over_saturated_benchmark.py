from pathlib import Path

import pytest

from tests.e2e.utils import (
    GuidellmClient,
    assert_constraint_triggered,
    assert_no_python_exceptions,
    load_benchmark_report,
)
from tests.e2e.vllm_sim_server import VllmSimServer


@pytest.fixture(scope="module")
def server():
    """
    Pytest fixture to start and stop the server for the entire module
    using the TestServer class.
    """
    server = VllmSimServer(
        port=8000,
        model="databricks/dolly-v2-12b",
        mode="random",
        time_to_first_token=60000,
        inter_token_latency=100,
        max_num_seqs=1,
    )
    try:
        server.start()
        yield server  # Yield the URL for tests to use
    finally:
        server.stop()  # Teardown: Stop the server after tests are done


@pytest.mark.timeout(60)
def test_over_saturated_benchmark(server: VllmSimServer, tmp_path: Path):
    """
    Test over-saturation detection using the --default-over-saturation flag.
    """
    report_name = "over_saturated_benchmarks.json"
    report_path = tmp_path / report_name
    rate = 10

    # Create and configure the guidellm client
    client = GuidellmClient(
        target=server.get_url(),
        output_dir=tmp_path,
        outputs=report_name,
    )

    # Start the benchmark with --default-over-saturation flag
    client.start_benchmark(
        rate=rate,
        max_seconds=20,
        over_saturation={"mode": "enforce", "min_seconds": 0},
        extra_env={
            "GOMAXPROCS": "1",
        },
    )

    # Wait for the benchmark to complete
    client.wait_for_completion(timeout=55)

    # Assert no Python exceptions occurred
    assert_no_python_exceptions(client.stderr)

    # Load and validate the report
    report = load_benchmark_report(report_path)
    benchmark = report["benchmarks"][0]

    # Check that the max duration constraint was triggered
    assert_constraint_triggered(
        benchmark, "over_saturation", {"is_over_saturated": True}
    )


@pytest.mark.timeout(60)
def test_over_saturated_benchmark_with_dict_config(
    server: VllmSimServer, tmp_path: Path
):
    """
    Test over-saturation detection with dictionary configuration instead of boolean.
    """
    report_name = "over_saturated_benchmarks_dict.json"
    report_path = tmp_path / report_name
    rate = 10

    # Create and configure the guidellm client
    client = GuidellmClient(
        target=server.get_url(),
        output_dir=tmp_path,
        outputs=report_name,
    )

    # Start the benchmark with dictionary configuration for over-saturation
    client.start_benchmark(
        rate=rate,
        max_seconds=20,
        over_saturation={
            "mode": "enforce",
            "min_seconds": 0,
            "max_window_seconds": 120.0,
            "moe_threshold": 2.0,
            "minimum_window_size": 5,
        },
        extra_env={
            "GOMAXPROCS": "1",
        },
    )

    # Wait for the benchmark to complete
    client.wait_for_completion(timeout=55)

    # Assert no Python exceptions occurred
    assert_no_python_exceptions(client.stderr)

    # Load and validate the report
    report = load_benchmark_report(report_path)
    benchmark = report["benchmarks"][0]

    # Check that the over-saturation constraint was triggered
    assert_constraint_triggered(
        benchmark, "over_saturation", {"is_over_saturated": True}
    )
