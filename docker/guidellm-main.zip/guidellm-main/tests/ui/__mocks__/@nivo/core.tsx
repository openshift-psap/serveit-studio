export const Point = () => null;
