"""
Copy required files from outside of the docs directory into the docs directory
for the documentation build and site.
Uses mkdocs-gen-files to handle the file generation and compatibility with MkDocs.
"""

import json
import runpy
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import cast

import mkdocs_gen_files

TranslationRoutes = dict[str, dict[str, str | bool]]
DOCS_ROOT = Path("docs")
ENGLISH_DOCS_ROOT = DOCS_ROOT / "en"


@dataclass
class ProcessFile:
    root_path: Path
    docs_path: Path
    title: str
    weight: float


def find_project_root() -> Path:
    start_path = Path(__file__).absolute()
    current_path = start_path.parent

    while current_path:
        if (current_path / "mkdocs.yml").exists():
            return current_path
        current_path = current_path.parent

    raise FileNotFoundError(
        f"Could not find mkdocs.yml in the directory tree starting from {start_path}"
    )


def process_files(files: list[ProcessFile], project_root: Path):
    for file in files:
        source_path = project_root / file.root_path
        target_path = file.docs_path

        if not source_path.exists():
            raise FileNotFoundError(
                f"Source file {source_path} does not exist for copying into docs "
                f"directory at {target_path}"
            )

        frontmatter = f"---\ntitle: {file.title}\nweight: {file.weight}\n---\n\n"
        content = source_path.read_text(encoding="utf-8")

        with mkdocs_gen_files.open(target_path, "w") as file_handle:
            file_handle.write(frontmatter)
            file_handle.write(content)

        mkdocs_gen_files.set_edit_path(target_path, source_path)


def migrate_developer_docs():
    project_root = find_project_root()
    files = [
        ProcessFile(
            root_path=Path("CODE_OF_CONDUCT.md"),
            docs_path=Path("developer/code-of-conduct.md"),
            title="Code of Conduct",
            weight=-10,
        ),
        ProcessFile(
            root_path=Path("CONTRIBUTING.md"),
            docs_path=Path("developer/contributing.md"),
            title="Contributing Guide",
            weight=-8,
        ),
        ProcessFile(
            root_path=Path("DEVELOPING.md"),
            docs_path=Path("developer/developing.md"),
            title="Development Guide",
            weight=-6,
        ),
    ]
    process_files(files, project_root)


def mirror_english_docs():
    """Publish English source files at the existing documentation routes."""
    project_root = find_project_root()
    source_root = project_root / ENGLISH_DOCS_ROOT

    for source_path in sorted(source_root.rglob("*.md")):
        target_path = source_path.relative_to(source_root)
        content = source_path.read_text(encoding="utf-8")

        with mkdocs_gen_files.open(target_path, "w") as file_handle:
            file_handle.write(content)

        mkdocs_gen_files.set_edit_path(
            target_path,
            source_path.relative_to(project_root),
        )


def generate_translation_map():
    """Expose translated routes and source currency to the documentation UI."""
    project_root = find_project_root()
    translation_module = runpy.run_path(
        str(project_root / "docs/scripts/check_translations.py")
    )
    manifests = cast(
        "dict[str, Path]",
        translation_module["TRANSLATION_MANIFESTS"],
    )
    route_builder = cast(
        "Callable[[Path, Path], TranslationRoutes]",
        translation_module["translation_routes"],
    )
    routes = {
        language: route_builder(project_root, manifest_path)
        for language, manifest_path in manifests.items()
    }

    content = (
        "// Generated during the MkDocs build. Do not edit.\n"
        "window.GUIDELLM_TRANSLATION_ROUTES = Object.freeze("
        f"{json.dumps(routes, ensure_ascii=False, sort_keys=True)}"
        ");\n"
    )

    with mkdocs_gen_files.open("scripts/translation-map.js", "w") as file_handle:
        file_handle.write(content)


mirror_english_docs()
migrate_developer_docs()
generate_translation_map()
