---
weight: -5
---

# Guides

Welcome to the GuideLLM guides section! Here you'll find comprehensive documentation covering key components and concepts of the GuideLLM platform. These guides will help you understand the inner workings of GuideLLM, how to configure its various components, and how to interpret benchmark results to optimize your LLM deployments.

Whether you're interested in understanding the system architecture, exploring supported backends, configuring datasets, analyzing metrics, or setting service level objectives, these guides provide the detailed information you need to make informed decisions about your LLM deployments.

## Key Guides

<div class="grid cards" markdown>

- :material-layers-outline:{ .lg .middle } Architecture

  ______________________________________________________________________

  Understanding the modular design of GuideLLM and how core components interact to evaluate LLM deployments.

  [:octicons-arrow-right-24: Architecture Overview](architecture.md)

- :material-server:{ .lg .middle } Backends

  ______________________________________________________________________

  Learn about supported LLM backends and how to set up OpenAI-compatible servers for benchmarking.

  [:octicons-arrow-right-24: Backend Guide](backends.md)

- :material-database:{ .lg .middle } Datasets

  ______________________________________________________________________

  Configure and use different data sources for benchmarking, including synthetic data, Hugging Face datasets, and file-based options.

  [:octicons-arrow-right-24: Dataset Guide](datasets.md)

- :material-chart-bar:{ .lg .middle } Metrics

  ______________________________________________________________________

  Explore the comprehensive metrics provided by GuideLLM to evaluate performance, including latency, throughput, and token-level analysis.

  [:octicons-arrow-right-24: Metrics Guide](metrics.md)

- :material-file-export:{ .lg .middle } Outputs

  ______________________________________________________________________

  Learn about supported output formats and how to customize result reporting for your benchmarks.

  [:octicons-arrow-right-24: Output Guide](outputs.md)

- :material-alert-outline:{ .lg .middle } Warnings

  ______________________________________________________________________

  Configure post-benchmark warnings from metric paths, thresholds, and notes on `--metrics`, in a scenario file, or in the environment.

  [:octicons-arrow-right-24: Warnings Guide](warnings.md)

- :material-target:{ .lg .middle } Service Level Objectives

  ______________________________________________________________________

  Define and implement SLOs and SLAs for your LLM deployments to ensure reliability and performance.

  [:octicons-arrow-right-24: SLO Guide](service_level_objectives.md)

- :material-stop-circle-outline:{ .lg .middle } Over-Saturation Stopping

  ______________________________________________________________________

  Automatically detect and stop benchmarks when models become over-saturated to prevent wasted compute resources and ensure valid results.

  [:octicons-arrow-right-24: Over-Saturation Guide](over_saturation_stopping.md)

- :material-chart-bell-curve-cumulative:{ .lg .middle } Knee Profile

  ______________________________________________________________________

  Find where throughput saturates and optionally run additional concurrency points around the detected knee.

  [:octicons-arrow-right-24: Knee Profile Guide](knee_detection.md)

- :material-wrench:{ .lg .middle } Tool Calling

  ______________________________________________________________________

  Benchmark multi-turn tool calling workloads with pre-anticipated tool call turns, synthetic data, and dataset-driven tool definitions.

  [:octicons-arrow-right-24: Tool Calling Guide](tool_calling.md)

- :material-image-multiple:{ .lg .middle } Multimodal Benchmarking

  ______________________________________________________________________

  Set up benchmarks for multimodal models including text+image, video, and audio tasks.

  [:octicons-arrow-right-24: Multimodal Guide](multimodal/index.md)

- :material-lifebuoy:{ .lg .middle } Troubleshooting

  ______________________________________________________________________

  How to troubleshoot common errors.

  [:octicons-arrow-right-24: Troubleshooting Guide](troubleshooting.md)

- :material-update:{ .lg .middle } v0.7.0 Migration Guide

  ______________________________________________________________________

  How to migrate GuideLLM CLI commandsfrom v0.6.0 to v0.7.0.

  [:octicons-arrow-right-24: v0.7.0 Migration Guide](v0.7.0_migration_guide.md)

</div>
